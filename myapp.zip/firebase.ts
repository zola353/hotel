import { initializeApp } from 'firebase/app';
import { getDatabase, ref } from 'firebase/database';

const firebaseConfig = {
  apiKey: "AIzaSyCVy5SMEmD0NBx9Y3nPCj7QxFUgljVz3sw",
  authDomain: "hidtu-6b42c.firebaseapp.com",
  databaseURL: "https://hidtu-6b42c-default-rtdb.firebaseio.com",
  projectId: "hidtu-6b42c",
  storageBucket: "hidtu-6b42c.firebasestorage.app",
  messagingSenderId: "895993292175",
  appId: "1:895993292175:web:47bfb88b5a25da58cd17fa",
  measurementId: "G-NQMHM1QPTF"
};

const app = initializeApp(firebaseConfig);
export const db = getDatabase(app);

export const refs = {
  users: ref(db, 'users'),
  store: ref(db, 'store'),
  waiterDebts: ref(db, 'waiterDebts'),
  tableOrders: ref(db, 'tableOrders'),
  salesHistory: ref(db, 'salesHistory'),
  waiterRatings: ref(db, 'waiterRatings'),
  complaints: ref(db, 'complaints'),
  feedbacks: ref(db, 'feedbacks'),
  barmanReceivedItems: ref(db, 'barmanReceivedItems'),
  games: ref(db, 'games'),
  hotelLocation: ref(db, 'hotelLocation'),
  marquee: ref(db, 'marquee'),
  whatsapp: ref(db, 'whatsapp')
};
