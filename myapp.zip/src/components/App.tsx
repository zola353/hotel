import React, { useState, useEffect } from 'react';
import { onValue, set, push, ref, child } from 'firebase/database';
import { db, refs } from './firebase';
import { User, StoreItem, TableOrder, WaiterDebt, SaleRecord, WaiterRating, Complaint, Feedback, Game, HotelLocation } from './types';
import { Key, Beer, Utensils, Dices, UserCheck, LogOut, CheckCircle, Smartphone } from 'lucide-react';
import QRCode from 'qrcode';

// Import custom components
import Marquee from './components/Marquee';
import Login from './components/Login';
import OwnerDashboard from './components/OwnerDashboard';
import BarmanDashboard from './components/BarmanDashboard';
import WaiterDashboard from './components/WaiterDashboard';
import GameDashboard from './components/GameDashboard';
import CustomerDashboard from './components/CustomerDashboard';
import { formatCurrency } from './utils';

export default function App() {
  // Global Synced States
  const [users, setUsers] = useState<User[]>([]);
  const [store, setStore] = useState<StoreItem[]>([]);
  const [tableOrders, setTableOrders] = useState<{ [tableId: string]: TableOrder }>({});
  const [waiterDebts, setWaiterDebts] = useState<{ [waiterId: string]: WaiterDebt[] }>({});
  const [salesHistory, setSalesHistory] = useState<SaleRecord[]>([]);
  const [waiterRatings, setWaiterRatings] = useState<{ [waiterId: string]: WaiterRating[] }>({});
  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [feedbacks, setFeedbacks] = useState<Feedback[]>([]);
  const [barmanReceivedItems, setBarmanReceivedItems] = useState<{ [barmanId: string]: { [code: string]: { name: string; qty: number; price: number } } }>({});
  const [games, setGames] = useState<Game[]>([]);
  const [hotelLocation, setHotelLocation] = useState<HotelLocation>({ lat: null, lng: null });
  const [marqueeText, setMarqueeText] = useState('');
  const [whatsappNumber, setWhatsappNumber] = useState('');

  // App Session States
  const [loggedInUser, setLoggedInUser] = useState<User | null>(null);
  const [currentRole, setCurrentRole] = useState<'owner' | 'barman' | 'waiter' | 'game' | 'customer'>('owner');
  const [customerActiveTable, setCustomerActiveTable] = useState<number>(1);

  // Checkout modal states
  const [showCheckoutModal, setShowCheckoutModal] = useState(false);
  const [activeCheckoutTableId, setActiveCheckoutTableId] = useState<string | null>(null);
  const [paymentMethod, setPaymentMethod] = useState<'Cash' | 'Bank'>('Cash');
  const [bankName, setBankName] = useState('CBE');
  const [bankRefNumber, setBankRefNumber] = useState('');
  const [qrCodeUrl, setQrCodeUrl] = useState('');
  const [paymentSuccess, setPaymentSuccess] = useState(false);

  // 1. Initial URL Params Check for Customer mode
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const isCustomer = params.get('customer') === '1' || params.get('mode') === 'customer';
    const table = parseInt(params.get('table') || '1');
    if (isCustomer) {
      setCustomerActiveTable(table);
      const dummyCustomer: User = { id: 'CUST01', name: 'ደንበኛ', role: 'customer' };
      setLoggedInUser(dummyCustomer);
      setCurrentRole('customer');
    }
  }, []);

  // 2. Attach Live Firebase Listeners
  useEffect(() => {
    // Users
    const unsubscribeUsers = onValue(refs.users, (snapshot) => {
      const data = snapshot.val();
      if (data) {
        setUsers(Object.values(data));
      } else {
        const defaultUsers: User[] = [
          { id: 'OWN01', name: 'ባለቤት', role: 'owner', password: '1234' },
          { id: 'BM01', name: 'ታሪኩ', role: 'barman', password: '5678' },
          { id: 'WT01', name: 'ሰብለ', role: 'waiter', password: '9012' },
          { id: 'GM01', name: 'አለሙ', role: 'game', password: '3456' }
        ];
        set(refs.users, defaultUsers);
        setUsers(defaultUsers);
      }
    });

    // Store
    const unsubscribeStore = onValue(refs.store, (snapshot) => {
      const data = snapshot.val();
      if (data) {
        setStore(Object.values(data));
      } else {
        const defaultStore: StoreItem[] = [
          { code: 'B1', name: 'ሀበሻ ቢራ', category: 'መጠጥ', cost: 50, price: 80, stock: 120 },
          { code: 'B2', name: 'ዳሽን ቢራ', category: 'መጠጥ', cost: 50, price: 80, stock: 100 },
          { code: 'D1', name: 'ድራፍት ሲንግል', category: 'መጠጥ', cost: 30, price: 50, stock: 200 },
          { code: 'F1', name: 'ሩብ ጥብስ', category: 'ምግብ', cost: 120, price: 200, stock: 50 },
          { code: 'F2', name: 'ሺሮ', category: 'ምግብ', cost: 60, price: 100, stock: 60 },
          { code: 'D2', name: 'ድራፍት ጃንቦ', category: 'መጠጥ', cost: 50, price: 90, stock: 150 },
          { code: 'F3', name: 'ተጋቢኖ', category: 'ምግብ', cost: 80, price: 140, stock: 40 },
          { code: 'J1', name: 'ጁስ', category: 'ደረቅ መጠጦች', cost: 20, price: 40, stock: 80 },
          { code: 'J2', name: 'ስፕራይት', category: 'ደረቅ መጠጦች', cost: 25, price: 50, stock: 70 }
        ];
        set(refs.store, defaultStore);
        setStore(defaultStore);
      }
    });

    // Table Orders
    const unsubscribeTableOrders = onValue(refs.tableOrders, (snapshot) => {
      setTableOrders(snapshot.val() || {});
    });

    // Waiter Debts
    const unsubscribeWaiterDebts = onValue(refs.waiterDebts, (snapshot) => {
      setWaiterDebts(snapshot.val() || {});
    });

    // Sales History - Fix formatting natively
    const unsubscribeSalesHistory = onValue(refs.salesHistory, (snapshot) => {
      const data = snapshot.val();
      setSalesHistory(data ? Object.values(data) : []);
    });

    // Waiter Ratings
    const unsubscribeWaiterRatings = onValue(refs.waiterRatings, (snapshot) => {
      setWaiterRatings(snapshot.val() || {});
    });

    // Complaints
    const unsubscribeComplaints = onValue(refs.complaints, (snapshot) => {
      const data = snapshot.val();
      setComplaints(data ? Object.keys(data).map(key => ({ ...(data[key] as any), firebaseKey: key })) : []);
    });

    // Feedbacks
    const unsubscribeFeedbacks = onValue(refs.feedbacks, (snapshot) => {
      const data = snapshot.val();
      setFeedbacks(data ? Object.values(data).reverse() : []);
    });

    // Barman Received Items
    const unsubscribeBarmanReceivedItems = onValue(refs.barmanReceivedItems, (snapshot) => {
      const data = snapshot.val() || {};
      const normalized: { [barmanId: string]: { [code: string]: { name: string; qty: number; price: number } } } = {};
      const firstVal = Object.values(data)[0];
      if (firstVal && typeof firstVal === 'object' && 'name' in firstVal) {
        normalized['BM01'] = data as any;
      } else {
        Object.entries(data).forEach(([bId, items]) => {
          normalized[bId] = items as any;
        });
      }
      setBarmanReceivedItems(normalized);
    });

    // Games
    const unsubscribeGames = onValue(refs.games, (snapshot) => {
      const data = snapshot.val();
      setGames(data ? Object.values(data) : []);
    });

    // Hotel Location
    const unsubscribeHotelLocation = onValue(refs.hotelLocation, (snapshot) => {
      setHotelLocation(snapshot.val() || { lat: null, lng: null });
    });

    // Marquee text
    const unsubscribeMarquee = onValue(refs.marquee, (snapshot) => {
      setMarqueeText(snapshot.val() || "እንኳን ወደ ሆቴላችን በደህና መጡ! ጥራት ያላቸውን ምግቦችና መጠጦች በፍጥነት እናቀርባለን።");
    });

    // WhatsApp Number
    const unsubscribeWhatsapp = onValue(refs.whatsapp, (snapshot) => {
      setWhatsappNumber(snapshot.val() || "");
    });

    return () => {
      unsubscribeUsers();
      unsubscribeStore();
      unsubscribeTableOrders();
      unsubscribeWaiterDebts();
      unsubscribeSalesHistory();
      unsubscribeWaiterRatings();
      unsubscribeComplaints();
      unsubscribeFeedbacks();
      unsubscribeBarmanReceivedItems();
      unsubscribeGames();
      unsubscribeHotelLocation();
      unsubscribeMarquee();
      unsubscribeWhatsapp();
    };
  }, []);

  // 3. Global Callback Actions

  const handleSaveWhatsApp = (num: string) => {
    set(refs.whatsapp, num);
  };

  const handleUpdateMarquee = (text: string) => {
    set(refs.marquee, text);
  };

  const handleCreateStaff = (name: string, role: 'barman' | 'waiter' | 'game') => {
    const prefix = role === 'barman' ? 'BM' : role === 'waiter' ? 'WT' : 'GM';
    const id = `${prefix}${String(users.filter(u => u.role === role).length + 1).padStart(2, '0')}`;
    const password = String(Math.floor(1000 + Math.random() * 9000));
    
    const updatedUsers = [...users, { id, name, role, password }];
    set(refs.users, updatedUsers);
    alert(`✅ ሰራተኛ ተፈጥሯል!\nስም: ${name}\nመለያ: ${id}\nፓስዎርድ: ${password}`);
  };

  const handleAddItemToStore = (item: StoreItem) => {
    const updatedStore = [...store, item];
    set(refs.store, updatedStore);
  };

  const handleUpdateItemPrice = (code: string, price: number) => {
    const updatedStore = store.map(item => {
      if (item.code === code) {
        return { ...item, price };
      }
      return item;
    });
    set(refs.store, updatedStore);
  };

  const handleSaveHotelLocation = (lat: number, lng: number) => {
    set(refs.hotelLocation, { lat, lng });
  };

  const handleClearWaiterDebt = (waiterId: string) => {
    const updatedDebts = { ...waiterDebts };
    updatedDebts[waiterId] = [];
    set(refs.waiterDebts, updatedDebts);
  };

  const handleDismissComplaint = (firebaseKey: string) => {
    const complaintRef = child(refs.complaints, firebaseKey);
    set(complaintRef, null);
  };

  // Owner Action: Handover items to barman
  const handleHandoverToBarman = (barmanId: string, itemCode: string, qty: number) => {
    // 1. Deduct from store stock (main warehouse)
    const updatedStore = store.map(item => {
      if (item.code === itemCode) {
        return { ...item, stock: Math.max(0, item.stock - qty) };
      }
      return item;
    });
    set(refs.store, updatedStore);

    // 2. Add to Barman's received inventory
    const updatedAllBarmenReceived = { ...barmanReceivedItems };
    const bReceived = { ...(updatedAllBarmenReceived[barmanId] || {}) };
    
    const sItem = store.find(i => i.code === itemCode);
    const name = sItem ? sItem.name : itemCode;
    const price = sItem ? sItem.price : 0;

    if (bReceived[itemCode]) {
      bReceived[itemCode] = {
        ...bReceived[itemCode],
        qty: bReceived[itemCode].qty + qty
      };
    } else {
      bReceived[itemCode] = { name, qty, price };
    }
    updatedAllBarmenReceived[barmanId] = bReceived;
    set(refs.barmanReceivedItems, updatedAllBarmenReceived);
  };

  // Owner Action: Clear/Settle Barman's debt & stock
  const handleClearBarmanDebt = (barmanId: string) => {
    const updatedAllBarmenReceived = { ...barmanReceivedItems };
    updatedAllBarmenReceived[barmanId] = {};
    set(refs.barmanReceivedItems, updatedAllBarmenReceived);
  };

  // Barman Action: Issue item to waiter
  const handleIssueItemToWaiter = (waiterId: string, itemCode: string, qty: number, barmanId: string) => {
    // 1. Deduct from Barman's received items stock
    const updatedAllBarmenReceived = { ...barmanReceivedItems };
    const bReceived = { ...updatedAllBarmenReceived[barmanId] };
    if (bReceived[itemCode]) {
      bReceived[itemCode] = {
        ...bReceived[itemCode],
        qty: Math.max(0, bReceived[itemCode].qty - qty)
      };
    }
    updatedAllBarmenReceived[barmanId] = bReceived;
    set(refs.barmanReceivedItems, updatedAllBarmenReceived);

    // 2. Increase waiter debt
    const updatedDebts = { ...waiterDebts };
    const currentWaiterDebts = [...(updatedDebts[waiterId] || [])];
    const sItem = store.find(i => i.code === itemCode);
    const price = sItem ? sItem.price : 0;
    const name = sItem ? sItem.name : itemCode;

    const existingIndex = currentWaiterDebts.findIndex(d => d.itemCode === itemCode);
    if (existingIndex !== -1) {
      currentWaiterDebts[existingIndex] = {
        ...currentWaiterDebts[existingIndex],
        qty: currentWaiterDebts[existingIndex].qty + qty
      };
    } else {
      currentWaiterDebts.push({ itemCode, qty, price });
    }
    updatedDebts[waiterId] = currentWaiterDebts;
    set(refs.waiterDebts, updatedDebts);
  };

  // Waiter Action: Submit a complaint
  const handleSubmitComplaint = (itemCode: string, qty: number, waiterId: string, waiterName: string) => {
    const sItem = store.find(i => i.code === itemCode);
    const itemName = sItem ? sItem.name : itemCode;
    push(refs.complaints, { waiterId, waiterName, itemName, qty });
  };

  // Waiter Action: Add order to table
  const handleAddOrderToTable = (tableId: number, itemCode: string, qty: number, waiterId: string) => {
    const updatedOrders = { ...tableOrders };
    const orderKey = tableId.toString();

    if (!updatedOrders[orderKey] || updatedOrders[orderKey].status === 'closed') {
      updatedOrders[orderKey] = { items: [], waiterId, status: 'open' };
    }

    const sItem = store.find(i => i.code === itemCode);
    if (!sItem) return;

    const existingIndex = updatedOrders[orderKey].items.findIndex(i => i.code === itemCode);
    if (existingIndex !== -1) {
      updatedOrders[orderKey].items[existingIndex].qty += qty;
    } else {
      updatedOrders[orderKey].items.push({
        code: itemCode,
        name: sItem.name,
        price: sItem.price,
        qty,
        source: 'waiter'
      });
    }

    set(refs.tableOrders, updatedOrders);
  };

  // Customer Action: Submit customer order live
  const handleAddCustomerOrder = (tableId: number, itemCode: string, qty: number, customerName: string) => {
    // Deduct stock
    const updatedStore = store.map(item => {
      if (item.code === itemCode) {
        return { ...item, stock: Math.max(0, item.stock - qty) };
      }
      return item;
    });
    set(refs.store, updatedStore);

    // Add to table orders
    const updatedOrders = { ...tableOrders };
    const orderKey = tableId.toString();

    if (!updatedOrders[orderKey] || updatedOrders[orderKey].status === 'closed') {
      // Default to first waiter to handle client if no waiter has taken it yet
      updatedOrders[orderKey] = { items: [], waiterId: 'WT01', status: 'open' };
    }

    const sItem = store.find(i => i.code === itemCode);
    if (!sItem) return;

    const existingIndex = updatedOrders[orderKey].items.findIndex(i => i.code === itemCode);
    if (existingIndex !== -1) {
      updatedOrders[orderKey].items[existingIndex].qty += qty;
    } else {
      updatedOrders[orderKey].items.push({
        code: itemCode,
        name: sItem.name,
        price: sItem.price,
        qty,
        source: 'customer'
      });
    }

    set(refs.tableOrders, updatedOrders);
  };

  // Customer Action: Rate waiter
  const handleSubmitRating = (waiterId: string, rating: number, customerName: string, tableId: number) => {
    const updatedRatings = { ...waiterRatings };
    const list = updatedRatings[waiterId] || [];
    list.push({ rating, date: new Date().toISOString(), tableId, customerName });
    updatedRatings[waiterId] = list;
    set(refs.waiterRatings, updatedRatings);
  };

  // Customer Action: Submit feedback directly to owner
  const handleSubmitFeedback = (tableId: number, message: string) => {
    push(refs.feedbacks, { tableId, message, time: new Date().toLocaleTimeString() });
  };

  // Game Action: Start Game
  const handleStartGame = (customerName: string, location: number) => {
    const updatedGames = [...games, {
      id: games.length + 1,
      customerName,
      location,
      startTime: new Date().toISOString(),
      endTime: null,
      minutes: 0,
      cost: 0,
      status: 'active' as const
    }];
    set(refs.games, updatedGames);
  };

  // Game Action: End Game
  const handleEndGame = (gameId: number) => {
    const updatedGames = games.map(g => {
      if (g.id === gameId && g.status === 'active') {
        const endTime = new Date().toISOString();
        const diffMs = new Date().getTime() - new Date(g.startTime).getTime();
        const minutes = Math.max(1, Math.floor(diffMs / 60000));
        const cost = minutes * 1.70;
        return { ...g, endTime, minutes, cost, status: 'closed' as const };
      }
      return g;
    });
    set(refs.games, updatedGames);
  };

  // Switch role action (with prompt passcode verification)
  const handleSwitchRole = (role: 'owner' | 'barman' | 'waiter' | 'game' | 'customer') => {
    if (!loggedInUser) return;
    if (loggedInUser.role === role) return;

    if (role === 'customer') {
      setLoggedInUser({ id: 'CUST01', name: 'ደንበኛ', role: 'customer' });
      setCurrentRole('customer');
      return;
    }

    const availableUsersOfRole = users.filter(u => u.role === role);
    if (availableUsersOfRole.length === 0) {
      return alert('በዚህ ሚና ምንም ተመዝጋቢ ሰራተኛ የለም!');
    }

    const userListPrompt = availableUsersOfRole.map((u, i) => `${i + 1}. ${u.name}`).join('\n');
    const choice = prompt(`ለ ${role} መቀየር የሚፈልጉትን ሰራተኛ ቁጥር ይምረጡ:\n${userListPrompt}\n\nቁጥር ያስገቡ (1-${availableUsersOfRole.length}):`);
    if (choice === null) return;

    const idx = parseInt(choice) - 1;
    if (isNaN(idx) || idx < 0 || idx >= availableUsersOfRole.length) {
      return alert('የተሳሳተ ምርጫ!');
    }

    const selectedUser = availableUsersOfRole[idx];
    const pwd = prompt(`ለ ${selectedUser.name} የደህንነት ፓስዎርድ ያስገቡ:`);
    if (pwd === null) return;

    if (pwd === selectedUser.password) {
      setLoggedInUser(selectedUser);
      setCurrentRole(role);
      alert(`✅ ወደ ሰራተኛ ${selectedUser.name} ተቀይረዋል!`);
    } else {
      alert('⛔ የተሳሳተ ፓስዎርድ!');
    }
  };

  // Open Checkout Modal
  const handleOpenCheckout = (tableId: string) => {
    setActiveCheckoutTableId(tableId);
    setPaymentMethod('Cash');
    setBankName('CBE');
    setBankRefNumber('');
    setQrCodeUrl('');
    setPaymentSuccess(false);
    setShowCheckoutModal(true);
  };

  // Close table & process sales checkout (THE CRITICAL FIXED CODE)
  const handleConfirmCheckout = async () => {
    if (!activeCheckoutTableId) return;
    const order = tableOrders[activeCheckoutTableId];
    if (!order) return;

    const grandTotal = order.items.reduce((sum, item) => sum + item.price * item.qty, 0);
    const waiterName = users.find(u => u.id === order.waiterId)?.name || 'አስተናጋጅ';

    // Calculate profit
    let profitTotal = 0;
    order.items.forEach(item => {
      const sItem = store.find(i => i.code === item.code);
      const cost = sItem ? sItem.cost : item.price;
      profitTotal += (item.price - cost) * item.qty;
    });

    const saleRecord: SaleRecord = {
      waiterId: order.waiterId,
      tableId: activeCheckoutTableId,
      items: [...order.items],
      total: grandTotal,
      profit: profitTotal,
      date: new Date().toISOString(),
      method: paymentMethod,
      bank: paymentMethod === 'Bank' ? bankName : 'N/A',
      ref: paymentMethod === 'Bank' ? bankRefNumber : 'N/A'
    };

    try {
      // 1. Record sale by pushing to list
      await push(refs.salesHistory, saleRecord);

      // 2. Set table orders status as closed
      const updatedOrders = { ...tableOrders };
      updatedOrders[activeCheckoutTableId].status = 'closed';
      await set(refs.tableOrders, updatedOrders);

      // 3. Deduct sold items from waiter debt list
      if (waiterDebts[order.waiterId]) {
        const updatedDebts = [...waiterDebts[order.waiterId]];
        order.items.forEach(item => {
          const idx = updatedDebts.findIndex(d => d.itemCode === item.code);
          if (idx !== -1) {
            const debt = updatedDebts[idx];
            if (debt.qty >= item.qty) {
              debt.qty -= item.qty;
              if (debt.qty === 0) {
                updatedDebts.splice(idx, 1);
              }
            }
          }
        });
        const allDebts = { ...waiterDebts };
        allDebts[order.waiterId] = updatedDebts;
        await set(refs.waiterDebts, allDebts);
      }

      // 4. Generate QR receipt data URL
      let qrText = `ሆቴል\nጠረጴዛ: ${activeCheckoutTableId}\n`;
      order.items.forEach(i => {
        qrText += `${i.name} x${i.qty} = ${i.price * i.qty} ብር\n`;
      });
      qrText += `ጠቅላላ: ${grandTotal} ብር\nአስተናጋጅ: ${waiterName}\nእናመሰግናለን!`;

      const qrUrl = await QRCode.toDataURL(qrText, { width: 180, margin: 2 });
      setQrCodeUrl(qrUrl);
      setPaymentSuccess(true);
      alert('✅ ሂሳቡ በተሳካ ሁኔታ ተዘግቶ ክፍያ ተፈጽሟል!');
    } catch (error) {
      console.error(error);
      alert('የሂሳብ መዝጊያው ላይ ስህተት ገጥሟል፦ ' + (error instanceof Error ? error.message : String(error)));
    }
  };

  const handleLogout = () => {
    if (confirm('እርግጠኛ ነዎት መውጣት ይፈልጋሉ?')) {
      setLoggedInUser(null);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 font-sans">
      {/* Dynamic Announcement Banner */}
      <Marquee text={marqueeText} />

      {/* LOGIN VIEW IF NOT AUTHENTICATED */}
      {!loggedInUser ? (
        <Login
          users={users}
          hotelLocation={hotelLocation}
          onLoginSuccess={(user) => {
            setLoggedInUser(user);
            setCurrentRole(user.role);
          }}
        />
      ) : (
        <div className="max-w-7xl mx-auto p-4 space-y-6 pb-24">
          {/* NAVIGATION BAR ROLE SELECTOR */}
          {loggedInUser.role !== 'customer' && loggedInUser.role !== 'game' && (
            <div className="flex flex-wrap items-center justify-center gap-2 bg-white p-3.5 rounded-3xl shadow-sm border border-slate-100">
              <button
                onClick={() => handleSwitchRole('owner')}
                className={`px-4 py-2 rounded-xl text-xs font-black transition-all cursor-pointer ${
                  currentRole === 'owner' ? 'bg-amber-500 text-white shadow-md' : 'bg-slate-50 hover:bg-slate-100 text-slate-700'
                }`}
              >
                🔑 ባለቤት
              </button>
              <button
                onClick={() => handleSwitchRole('barman')}
                className={`px-4 py-2 rounded-xl text-xs font-black transition-all cursor-pointer ${
                  currentRole === 'barman' ? 'bg-indigo-600 text-white shadow-md' : 'bg-slate-50 hover:bg-slate-100 text-slate-700'
                }`}
              >
                🍺 ባርማን
              </button>
              <button
                onClick={() => handleSwitchRole('waiter')}
                className={`px-4 py-2 rounded-xl text-xs font-black transition-all cursor-pointer ${
                  currentRole === 'waiter' ? 'bg-orange-500 text-white shadow-md' : 'bg-slate-50 hover:bg-slate-100 text-slate-700'
                }`}
              >
                🍽️ አስተናጋጅ
              </button>
              <button
                onClick={() => handleSwitchRole('game')}
                className={`px-4 py-2 rounded-xl text-xs font-black transition-all cursor-pointer ${
                  currentRole === 'game' ? 'bg-purple-600 text-white shadow-md' : 'bg-slate-50 hover:bg-slate-100 text-slate-700'
                }`}
              >
                🎮 ካራንቡላ
              </button>
              <button
                onClick={() => handleSwitchRole('customer')}
                className={`px-4 py-2 rounded-xl text-xs font-black transition-all cursor-pointer ${
                  currentRole === 'customer' ? 'bg-emerald-500 text-white shadow-md' : 'bg-slate-50 hover:bg-slate-100 text-slate-700'
                }`}
              >
                📱 QR ደንበኛ
              </button>

              {/* simulated table for testing customer views */}
              <div className="flex items-center gap-1.5 ml-4 border-l pl-4 bg-slate-50 p-1 rounded-xl">
                <label className="text-[10px] font-bold text-slate-500">ጠረጴዛ ቀይር፦</label>
                <select
                  value={customerActiveTable}
                  onChange={(e) => setCustomerActiveTable(parseInt(e.target.value))}
                  className="border text-xs rounded-lg p-1 bg-white font-bold text-slate-800 focus:outline-none"
                >
                  {Array.from({ length: 30 }, (_, i) => i + 1).map((tNum) => (
                    <option key={tNum} value={tNum}>ጠረጴዛ {tNum}</option>
                  ))}
                </select>
              </div>
            </div>
          )}

          {/* ACTIVE CONTENT VIEW BASED ON ACTIVE SELECTED ROLE */}
          {currentRole === 'owner' && (
            <OwnerDashboard
              users={users}
              store={store}
              waiterDebts={waiterDebts}
              salesHistory={salesHistory}
              waiterRatings={waiterRatings}
              complaints={complaints}
              feedbacks={feedbacks}
              hotelLocation={hotelLocation}
              whatsappNumber={whatsappNumber}
              onSaveWhatsApp={handleSaveWhatsApp}
              onUpdateMarquee={handleUpdateMarquee}
              onCreateStaff={handleCreateStaff}
              onAddItemToStore={handleAddItemToStore}
              onUpdateItemPrice={handleUpdateItemPrice}
              onSaveHotelLocation={handleSaveHotelLocation}
              onClearWaiterDebt={handleClearWaiterDebt}
              onDismissComplaint={handleDismissComplaint}
              barmanReceivedItems={barmanReceivedItems}
              games={games}
              onHandoverToBarman={handleHandoverToBarman}
              onClearBarmanDebt={handleClearBarmanDebt}
              onStartGame={handleStartGame}
              onEndGame={handleEndGame}
            />
          )}

          {currentRole === 'barman' && (
            <BarmanDashboard
              users={users}
              store={store}
              waiterDebts={waiterDebts}
              barmanReceivedItems={loggedInUser ? (barmanReceivedItems[loggedInUser.id] || {}) : {}}
              tableOrders={tableOrders}
              onIssueItemToWaiter={handleIssueItemToWaiter}
            />
          )}

          {currentRole === 'waiter' && (
            <WaiterDashboard
              currentUser={loggedInUser}
              users={users}
              store={store}
              waiterDebts={waiterDebts}
              tableOrders={tableOrders}
              onSubmitComplaint={handleSubmitComplaint}
              onAddOrderToTable={handleAddOrderToTable}
              onOpenCheckout={handleOpenCheckout}
              salesHistory={salesHistory}
            />
          )}

          {currentRole === 'game' && (
            <GameDashboard
              games={games}
              onStartGame={handleStartGame}
              onEndGame={handleEndGame}
            />
          )}

          {currentRole === 'customer' && (
            <CustomerDashboard
              tableNum={customerActiveTable}
              store={store}
              tableOrders={tableOrders}
              users={users}
              onAddCustomerOrder={handleAddCustomerOrder}
              onSubmitRating={handleSubmitRating}
              onSubmitFeedback={handleSubmitFeedback}
            />
          )}

          {/* FIXED BOTTOM FLOATING ACTIONS (WHATSAPP FLOAT & LOGOUT) */}
          <button
            onClick={handleLogout}
            className="fixed bottom-5 right-5 z-40 bg-red-500 hover:bg-red-600 text-white font-extrabold px-5 py-2.5 rounded-full shadow-lg flex items-center gap-1.5 cursor-pointer text-xs transition-transform active:scale-95"
          >
            <LogOut size={16} /> 🚪 ውጣ
          </button>

          {whatsappNumber && (
            <a
              href={`https://wa.me/${whatsappNumber.replace(/\D/g, '')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="fixed bottom-16 right-5 z-40 bg-emerald-500 hover:bg-emerald-600 text-white font-extrabold px-5 py-2.5 rounded-full shadow-lg flex items-center gap-1.5 text-xs transition-transform hover:scale-105 active:scale-95"
            >
              <Smartphone size={16} /> 💬 ዋትስአፕ
            </a>
          )}
        </div>
      )}

      {/* CHECKOUT / CLOSE BILL MODAL */}
      {showCheckoutModal && activeCheckoutTableId && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white p-6 rounded-3xl max-w-sm w-full space-y-4 shadow-2xl border">
            <h3 className="text-base font-black text-slate-800 tracking-tight">🧾 ክፍያ መዝጊያና ደረሰኝ ማተሚያ</h3>

            <div className="bg-slate-50 p-3 rounded-2xl border border-slate-100 text-xs text-slate-600 font-semibold space-y-1">
              <p><strong>ጠረጴዛ፦</strong> ጠረጴዛ {activeCheckoutTableId}</p>
              <p className="text-sm text-slate-800 font-extrabold">
                <strong>ጠቅላላ ሂሳብ፦</strong> {formatCurrency(tableOrders[activeCheckoutTableId]?.items.reduce((s, i) => s + i.price * i.qty, 0) || 0)}
              </p>
            </div>

            {!paymentSuccess ? (
              <>
                <div className="space-y-1">
                  <label className="block text-[10px] font-bold text-slate-500 uppercase">የክፍያ ዘዴ</label>
                  <select
                    value={paymentMethod}
                    onChange={(e: any) => setPaymentMethod(e.target.value)}
                    className="w-full border p-2.5 rounded-xl text-xs font-bold bg-white focus:outline-none"
                  >
                    <option value="Cash">💵 ካሽ (Cash)</option>
                    <option value="Bank">🏦 ባንክ (Bank Transfer)</option>
                  </select>
                </div>

                {paymentMethod === 'Bank' && (
                  <div className="space-y-2 bg-slate-50 p-3 rounded-2xl border">
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 uppercase">የባንክ አይነት</label>
                      <select
                        value={bankName}
                        onChange={(e) => setBankName(e.target.value)}
                        className="w-full border p-2 rounded-xl text-xs font-bold bg-white focus:outline-none mt-1"
                      >
                        <option value="CBE">CBE (የኢትዮጵያ ንግድ ባንክ)</option>
                        <option value="Awash">አዋሽ ባንክ (Awash Bank)</option>
                        <option value="Abyssinia">አቢሲኒያ ባንክ (BoA)</option>
                        <option value="Telebirr">ቴሌብር (telebirr)</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 uppercase">የግብይት መለያ (Ref No.)</label>
                      <input
                        type="text"
                        placeholder="ለምሳሌ፡ FT230987..."
                        value={bankRefNumber}
                        onChange={(e) => setBankRefNumber(e.target.value)}
                        className="w-full border p-2 rounded-xl text-xs font-semibold focus:outline-none mt-1"
                      />
                    </div>
                  </div>
                )}

                <button
                  onClick={handleConfirmCheckout}
                  className="w-full bg-emerald-600 hover:bg-emerald-700 text-white py-2.5 rounded-xl font-bold text-xs cursor-pointer shadow"
                >
                  ሂሳብ ዝጋና ደረሰኝ ፍጠር
                </button>
              </>
            ) : (
              <div className="flex flex-col items-center text-center space-y-3">
                <div className="p-2 bg-emerald-50 border border-emerald-100 rounded-2xl text-emerald-700 text-xs font-bold flex items-center gap-1.5 w-full justify-center">
                  <CheckCircle size={14} /> የጠረጴዛ {activeCheckoutTableId} ሂሳብ በተሳካ ሁኔታ ተዘግቷል!
                </div>
                {qrCodeUrl && (
                  <div className="p-3 bg-white border border-slate-100 rounded-2xl shadow-sm">
                    <img src={qrCodeUrl} alt="Receipt QR" />
                  </div>
                )}
                <p className="text-[10px] text-slate-400 font-bold">
                  ይህ ዲጂታል ደረሰኝ የክፍያ ማረጋገጫ QR ኮድን ይዟል።
                </p>
              </div>
            )}

            <button
              onClick={() => setShowCheckoutModal(false)}
              className="w-full bg-slate-100 hover:bg-slate-200 text-slate-700 py-2.5 rounded-xl font-bold text-xs cursor-pointer"
            >
              ዝጋ / ተመለስ
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
