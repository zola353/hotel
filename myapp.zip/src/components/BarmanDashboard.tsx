import React, { useState } from 'react';
import { User, StoreItem, WaiterDebt } from '../types';
import { Beer, Plus, Clipboard, UserCheck, Scale, Bell } from 'lucide-react';
import { formatCurrency } from '../utils';

interface BarmanDashboardProps {
  users: User[];
  store: StoreItem[];
  waiterDebts: { [waiterId: string]: WaiterDebt[] };
  barmanReceivedItems: { [code: string]: { name: string; qty: number; price: number } };
  tableOrders: { [tableId: string]: any };
  onIssueItemToWaiter: (waiterId: string, itemCode: string, qty: number, barmanId: string) => void;
}

export default function BarmanDashboard({
  users,
  store,
  waiterDebts,
  barmanReceivedItems,
  tableOrders,
  onIssueItemToWaiter,
}: BarmanDashboardProps) {
  const [selectedWaiterId, setSelectedWaiterId] = useState('');
  const [selectedItemCode, setSelectedItemCode] = useState('');
  const [itemQty, setItemQty] = useState('1');
  const [activeBarmanId, setActiveBarmanId] = useState('');

  // Selected waiter to view debt details
  const [inspectedWaiterId, setInspectedWaiterId] = useState<string | null>(null);

  // Accordion toggle
  const [openSection, setOpenSection] = useState<{ [key: string]: boolean }>({
    received: true,
    issued: true,
    balance: true,
    waiters: true,
  });

  const toggleSection = (sec: string) => {
    setOpenSection(prev => ({ ...prev, [sec]: !prev[sec] }));
  };

  const waiters = users.filter(u => u.role === 'waiter');
  const barmen = users.filter(u => u.role === 'barman');

  // Calculate totals
  const totalReceivedValue = Object.values(barmanReceivedItems).reduce((sum, item) => sum + item.qty * item.price, 0);
  
  const totalIssuedValue = Object.entries(waiterDebts).reduce((sum, [wid, list]) => {
    return sum + list.reduce((s, item) => s + item.qty * item.price, 0);
  }, 0);

  const balanceValue = totalReceivedValue - totalIssuedValue;

  const handleIssueItem = () => {
    if (!selectedWaiterId || !selectedItemCode || !itemQty || !activeBarmanId) {
      return alert('እባክዎ ሙሉ መረጃዎችን ይሙሉ!');
    }
    const qty = parseInt(itemQty);
    if (isNaN(qty) || qty <= 0) return alert('ትክክለኛ ቁጥር ያስገቡ');

    const sItem = store.find(i => i.code === selectedItemCode);
    if (!sItem) return alert('ዕቃው አልተገኘም');
    if (sItem.stock < qty) return alert(`በቂ ቀሪ ክምችት የለም! ቀሪ: ${sItem.stock}`);

    onIssueItemToWaiter(selectedWaiterId, selectedItemCode, qty, activeBarmanId);
    setItemQty('1');
    alert('📦 ዕቃ ለአስተናጋጅ ተጭኗል!');
  };

  return (
    <div className="space-y-6">
      {/* HEADER */}
      <div className="bg-white p-5 md:p-6 rounded-3xl shadow-md border-t-4 border-indigo-600">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-xl md:text-2xl font-black text-slate-800 tracking-tight font-display flex items-center gap-2">
              <Beer className="text-indigo-600 animate-bounce" /> 🍺 የባርማን መቆጣጠሪያ ፓነል
            </h2>
            <p className="text-xs text-slate-500 font-medium mt-1">ለአስተናጋጆች ዕቃ መጫን፣ ርክክብ እና የባር ቀሪ ባላንስ መከታተያ</p>
          </div>
          <span className="text-xs font-bold bg-indigo-50 text-indigo-700 border border-indigo-100 px-3 py-1.5 rounded-full self-start md:self-center">
            ባርማን (Barman)
          </span>
        </div>
      </div>

      {/* BALANCE SHEET METRIC CARDS */}
      <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
        <div
          onClick={() => toggleSection('balance')}
          className="p-4 font-bold text-slate-800 flex justify-between items-center bg-slate-50 border-b border-slate-100 cursor-pointer select-none"
        >
          <span className="flex items-center gap-2"><Scale className="text-indigo-600" /> ⚖️ የባላንስ መከታተያ ሰሌዳ</span>
          <span className="text-[11px] bg-slate-200 px-3 py-1 rounded-full font-bold">መንካት</span>
        </div>

        {openSection.balance && (
          <div className="p-4 grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
            <div className="bg-emerald-50 border border-emerald-200 p-4 rounded-2xl">
              <span className="block text-[10px] text-emerald-800 font-bold uppercase tracking-wider">ከስቶር የተረከቡት</span>
              <span className="text-xl font-black text-emerald-700 block mt-1">{formatCurrency(totalReceivedValue)}</span>
            </div>
            <div className="bg-red-50 border border-red-200 p-4 rounded-2xl">
              <span className="block text-[10px] text-red-800 font-bold uppercase tracking-wider">ለአስተናጋጅ ያስረከቡት</span>
              <span className="text-xl font-black text-red-700 block mt-1">{formatCurrency(totalIssuedValue)}</span>
            </div>
            <div className="bg-blue-50 border border-blue-200 p-4 rounded-2xl">
              <span className="block text-[10px] text-blue-800 font-bold uppercase tracking-wider">ቀሪ የባር ባላንስ</span>
              <span className="text-xl font-black text-blue-700 block mt-1">{formatCurrency(balanceValue)}</span>
            </div>
          </div>
        )}
      </div>

      {/* STORE TO BARMAN RECEIVED */}
      <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
        <div
          onClick={() => toggleSection('received')}
          className="p-4 font-bold text-slate-800 flex justify-between items-center bg-slate-50 border-b border-slate-100 cursor-pointer select-none"
        >
          <span className="flex items-center gap-2"><Clipboard className="text-emerald-600" /> 📥 ከስቶር የተረከቡት ዝርዝር</span>
          <span className="text-[11px] bg-slate-200 px-3 py-1 rounded-full font-bold">መንካት</span>
        </div>

        {openSection.received && (
          <div className="p-4">
            <div className="overflow-x-auto rounded-2xl border border-slate-100">
              <table className="min-w-full bg-white text-xs text-left">
                <thead className="bg-slate-50 border-b border-slate-100 font-extrabold text-slate-700">
                  <tr>
                    <th className="p-3">አገልግሎት (የዕቃ ስም)</th>
                    <th className="p-3 text-center">የተረከቡት ብዛት</th>
                    <th className="p-3 text-right">ዋጋ በአንድ</th>
                    <th className="p-3 text-right">ጠቅላላ ዋጋ</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium">
                  {Object.entries(barmanReceivedItems).map(([code, item]) => (
                    <tr key={code} className="hover:bg-slate-50/50">
                      <td className="p-3 font-bold text-slate-800">{item.name}</td>
                      <td className="p-3 text-center font-extrabold text-slate-800">{item.qty}</td>
                      <td className="p-3 text-right">{formatCurrency(item.price)}</td>
                      <td className="p-3 text-right font-black text-emerald-600">{formatCurrency(item.qty * item.price)}</td>
                    </tr>
                  ))}
                  {Object.keys(barmanReceivedItems).length === 0 && (
                    <tr>
                      <td colSpan={4} className="p-6 text-center text-slate-400 italic font-bold">
                        ባለቤቱ እስካሁን ምንም እቃ በኮድ አልጫነሎትም።
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* WAITER LOAD MANAGEMENT */}
      <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
        <div
          onClick={() => toggleSection('waiters')}
          className="p-4 font-bold text-slate-800 flex justify-between items-center bg-slate-50 border-b border-slate-100 cursor-pointer select-none"
        >
          <span className="flex items-center gap-2"><UserCheck className="text-indigo-600" /> 🔍 በአስተናጋጆች ላይ የተጫነ ቀሪ እዳ ዝርዝር</span>
          <span className="text-[11px] bg-slate-200 px-3 py-1 rounded-full font-bold">መንካት</span>
        </div>

        {openSection.waiters && (
          <div className="p-4 space-y-4">
            {/* Waiters buttons selector */}
            <div className="flex flex-wrap gap-2">
              {waiters.map(w => {
                const list = waiterDebts[w.id] || [];
                const sum = list.reduce((s, item) => s + item.qty * item.price, 0);
                return (
                  <button
                    key={w.id}
                    onClick={() => setInspectedWaiterId(w.id)}
                    className={`px-3 py-2 text-xs font-bold rounded-xl cursor-pointer transition-all border ${
                      inspectedWaiterId === w.id
                        ? 'bg-indigo-600 border-indigo-600 text-white shadow-md'
                        : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    {w.name} ({formatCurrency(sum)})
                  </button>
                );
              })}
            </div>

            {/* Inspected details */}
            {inspectedWaiterId && (
              <div className="p-4 bg-slate-50 border rounded-2xl space-y-3">
                <div className="flex justify-between items-center">
                  <h4 className="text-xs font-black text-slate-800">
                    🔍 ለአስተናጋጅ "{users.find(u => u.id === inspectedWaiterId)?.name}" የተጫኑ ዕቃዎች
                  </h4>
                  <button
                    onClick={() => setInspectedWaiterId(null)}
                    className="text-[10px] bg-slate-200 hover:bg-slate-300 font-bold px-2.5 py-1 rounded-lg"
                  >
                    ዝርዝር ዝጋ
                  </button>
                </div>
                
                <div className="overflow-x-auto rounded-xl border border-slate-100 bg-white">
                  <table className="min-w-full text-[11px] text-left">
                    <thead className="bg-slate-50 border-b font-extrabold text-slate-600">
                      <tr>
                        <th className="p-2">የእቃ ስም</th>
                        <th className="p-2 text-center">ቀሪ ብዛት</th>
                        <th className="p-2 text-right">የመሸጫ ዋጋ</th>
                        <th className="p-2 text-right">ድምር</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y font-semibold">
                      {(waiterDebts[inspectedWaiterId] || []).map((d, idx) => {
                        const sItem = store.find(i => i.code === d.itemCode);
                        const name = sItem ? sItem.name : d.itemCode;
                        return (
                          <tr key={idx}>
                            <td className="p-2 font-bold text-slate-700">{name}</td>
                            <td className="p-2 text-center font-extrabold text-slate-800">{d.qty}</td>
                            <td className="p-2 text-right">{formatCurrency(d.price)}</td>
                            <td className="p-2 text-right font-black text-emerald-600">{formatCurrency(d.qty * d.price)}</td>
                          </tr>
                        );
                      })}
                      {(waiterDebts[inspectedWaiterId] || []).length === 0 && (
                        <tr>
                          <td colSpan={4} className="p-4 text-center text-slate-400 italic">
                            ምንም ዕቃ አልተጫነበትም
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* ISSUE NEW ITEM FORM */}
      <div className="p-5 bg-white border border-slate-100 shadow-sm rounded-3xl space-y-4">
        <h3 className="font-extrabold text-indigo-800 text-sm flex items-center gap-1.5">
          <Plus size={18} /> ለአስተናጋጅ አዲስ ዕቃ መጫኛ/ርክክብ ማድረጊያ ፎርም
        </h3>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 bg-slate-50 p-4 rounded-2xl border">
          <div>
            <label className="block text-[10px] font-bold text-slate-500 mb-1 uppercase">ርክክብ ያደረገው ባርማን</label>
            <select
              value={activeBarmanId}
              onChange={(e) => setActiveBarmanId(e.target.value)}
              className="w-full border p-2.5 rounded-xl text-xs font-bold bg-white focus:outline-none"
            >
              <option value="">-- ባርማን ይምረጡ --</option>
              {barmen.map(b => (
                <option key={b.id} value={b.id}>{b.name}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[10px] font-bold text-slate-500 mb-1 uppercase">ተረካቢው አስተናጋጅ</label>
            <select
              value={selectedWaiterId}
              onChange={(e) => setSelectedWaiterId(e.target.value)}
              className="w-full border p-2.5 rounded-xl text-xs font-bold bg-white focus:outline-none"
            >
              <option value="">-- አስተናጋጅ ይምረጡ --</option>
              {waiters.map(w => (
                <option key={w.id} value={w.id}>{w.name}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[10px] font-bold text-slate-500 mb-1 uppercase">የዕቃ አይነት</label>
            <select
              value={selectedItemCode}
              onChange={(e) => setSelectedItemCode(e.target.value)}
              className="w-full border p-2.5 rounded-xl text-xs font-bold bg-white focus:outline-none"
            >
              <option value="">-- መጠጥ/ዕቃ ይምረጡ --</option>
              {store.map(i => (
                <option key={i.code} value={i.code}>{i.name} (ቀሪ ክምችት: {i.stock})</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[10px] font-bold text-slate-500 mb-1 uppercase">የዕቃው ብዛት</label>
            <input
              type="number"
              min="1"
              value={itemQty}
              onChange={(e) => setItemQty(e.target.value)}
              className="w-full border p-2.5 rounded-xl text-xs font-bold bg-white focus:outline-none text-center"
            />
          </div>
        </div>

        <button
          onClick={handleIssueItem}
          className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold px-6 py-3 rounded-2xl text-xs shadow-md shadow-indigo-500/10 hover:shadow-lg hover:shadow-indigo-500/20 active:scale-98 transition-all cursor-pointer"
        >
          እቃውን ጫን/አስረክብ
        </button>
      </div>

      {/* CUSTOMER ACTIVE ORDERS PANELS */}
      <div className="p-5 bg-orange-50/50 border border-orange-200 shadow-sm rounded-3xl space-y-3">
        <h3 className="font-extrabold text-orange-800 text-sm flex items-center gap-1.5">
          <Bell className="text-orange-500 animate-swing" /> 🔔 ከደንበኞች የደረሱ ንቁ ዲጂታል ትዕዛዞች
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {Object.entries(tableOrders)
            .filter(([_, ord]) => ord.status === 'open')
            .map(([tableId, ord]) => {
              const total = ord.items.reduce((s: number, i: any) => s + i.price * i.qty, 0);
              const summaryText = ord.items.map((i: any) => `${i.name} (${i.qty})`).join(', ');
              return (
                <div key={tableId} className="bg-white p-3.5 rounded-2xl border border-orange-100 shadow-sm space-y-1">
                  <div className="flex justify-between items-center border-b pb-1.5">
                    <span className="font-black text-xs text-orange-700">🍽️ ጠረጴዛ {tableId}</span>
                    <span className="text-[10px] font-bold text-slate-400">ትዕዛዝ</span>
                  </div>
                  <p className="text-xs font-medium text-slate-600 line-clamp-2">{summaryText}</p>
                  <p className="text-xs font-black text-emerald-600 pt-1">ድምር፦ {formatCurrency(total)}</p>
                </div>
              );
            })}
          {Object.entries(tableOrders).filter(([_, ord]) => ord.status === 'open').length === 0 && (
            <div className="col-span-full py-6 text-center text-orange-400 italic font-bold text-xs">
              በአሁን ሰዓት ምንም ንቁ የደንበኛ ትዕዛዞች የሉም
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
