import React, { useState } from 'react';
import { User, StoreItem, WaiterDebt, TableOrder } from '../types';
import { Utensils, AlertTriangle, Clipboard, Plus, CheckCircle, Smartphone, Globe, Download, QrCode } from 'lucide-react';
import { formatCurrency, downloadExcel } from '../utils';

interface WaiterDashboardProps {
  currentUser: User;
  users: User[];
  store: StoreItem[];
  waiterDebts: { [waiterId: string]: WaiterDebt[] };
  tableOrders: { [tableId: string]: TableOrder };
  onSubmitComplaint: (itemCode: string, qty: number, waiterId: string, waiterName: string) => void;
  onAddOrderToTable: (tableId: number, itemCode: string, qty: number, waiterId: string) => void;
  onOpenCheckout: (tableId: string) => void;
  salesHistory: any[];
}

export default function WaiterDashboard({
  currentUser,
  users,
  store,
  waiterDebts,
  tableOrders,
  onSubmitComplaint,
  onAddOrderToTable,
  onOpenCheckout,
  salesHistory,
}: WaiterDashboardProps) {
  const [tableInput, setTableInput] = useState('');
  const [selectedCode, setSelectedCode] = useState('');
  const [orderQty, setOrderQty] = useState('1');

  // Complaint form states
  const [complaintItem, setComplaintItem] = useState('');
  const [complaintQtyVal, setComplaintQtyVal] = useState('');
  const [showComplaintDetails, setShowComplaintDetails] = useState(false);

  const debts = waiterDebts[currentUser.id] || [];
  const totalDebt = debts.reduce((sum, d) => sum + d.qty * d.price, 0);

  // Active orders created by this waiter
  const activeTables = Object.entries(tableOrders).filter(
    ([_, ord]) => ord.status === 'open' && ord.waiterId === currentUser.id
  );

  // Today's waiter sales calculation
  const waiterTodaySales = salesHistory
    .filter(s => s.waiterId === currentUser.id && new Date(s.date).toDateString() === new Date().toDateString())
    .reduce((sum, s) => sum + s.total, 0);

  const handleAddOrder = () => {
    const tId = parseInt(tableInput);
    if (isNaN(tId) || tId < 1 || tId > 30) {
      return alert('እባክዎ ትክክለኛ የጠረጴዛ ቁጥር ያስገቡ (1-30)');
    }
    if (!selectedCode || !orderQty) {
      return alert('እባክዎ ዕቃና ብዛት ይምረጡ');
    }
    const qty = parseInt(orderQty);
    if (isNaN(qty) || qty <= 0) return alert('ትክክለኛ ቁጥር ያስገቡ');

    onAddOrderToTable(tId, selectedCode, qty, currentUser.id);
    setOrderQty('1');
    alert(`ትዕዛዝ ለጠረጴዛ ${tId} ተጨምሯል!`);
  };

  const handleSendComplaint = () => {
    if (!complaintItem || !complaintQtyVal) {
      return alert('እባክዎ ዕቃና የጎደለውን ብዛት ያስገቡ');
    }
    const qty = parseInt(complaintQtyVal);
    if (isNaN(qty) || qty <= 0) return alert('ትክክለኛ ብዛት ያስገቡ');

    onSubmitComplaint(complaintItem, qty, currentUser.id, currentUser.name);
    setComplaintItem('');
    setComplaintQtyVal('');
    alert('የዕቃ ቅሬታዎ ለባለቤቱ ተልኳል!');
  };

  const handleExportMySales = () => {
    const mySales = salesHistory
      .filter(s => s.waiterId === currentUser.id)
      .map((s, idx) => ({
        'ተ.ቁ': idx + 1,
        'ጠረጴዛ': s.tableId,
        'ምግቦች/መጠጦች': s.items.map((i: any) => `${i.name} (x${i.qty})`).join(', '),
        'ጠቅላላ ሽያጭ': s.total,
        'ዘዴ': s.method,
        'ባንክ': s.bank,
        'ቀን': new Date(s.date).toLocaleString()
      }));
    downloadExcel(mySales, `የኔ_ሽያጭ_ሪፖርት_${currentUser.name}`);
  };

  return (
    <div className="space-y-6">
      {/* HEADER CARD */}
      <div className="bg-gradient-to-r from-orange-500 via-amber-500 to-yellow-500 p-6 rounded-3xl shadow-xl text-white">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <span className="bg-white/25 backdrop-blur-md px-3.5 py-1 rounded-full text-[10px] font-extrabold uppercase tracking-widest text-white border border-white/20">
              አስተናጋጅ ፓነል (Waiter Panel)
            </span>
            <h2 className="text-2xl font-black tracking-tight font-display mt-2">
              🍽️ ሰላም፣ {currentUser.name}
            </h2>
            <p className="text-xs text-white/90 font-medium mt-1">የጠረጴዛ ትዕዛዞች ማስተናገጃ እና እዳ መከታተያ</p>
          </div>
          <div className="flex flex-col gap-1 items-end bg-black/10 backdrop-blur-md p-3.5 rounded-2xl border border-white/10 w-full md:w-auto">
            <span className="text-[10px] font-bold text-orange-100 uppercase tracking-wider">የዛሬ ጠቅላላ ሽያጭዎ</span>
            <span className="text-xl font-black text-white">{formatCurrency(waiterTodaySales)}</span>
          </div>
        </div>

        {/* Debt summary block */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-5 pt-5 border-t border-white/20">
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-4 border border-white/15 flex flex-col justify-between">
            <div className="flex justify-between items-center">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-orange-100">ያለብዎት ቀሪ ዕዳ (ለባር)</span>
                <span className="text-xl font-black block mt-0.5">{formatCurrency(totalDebt)}</span>
              </div>
              <button
                onClick={() => setShowComplaintDetails(!showComplaintDetails)}
                className="text-[10px] font-black bg-white text-orange-600 px-3 py-2 rounded-xl shadow cursor-pointer transition-all shrink-0 hover:bg-orange-50"
              >
                እቃ ዝርዝር / ቅሬታ
              </button>
            </div>

            {/* COMPLAINT SUBSECTION */}
            {showComplaintDetails && (
              <div className="mt-4 pt-4 border-t border-white/25 space-y-3">
                <div className="overflow-x-auto rounded-xl border border-white/10 bg-black/20 p-2 text-xs">
                  <table className="min-w-full text-left">
                    <thead>
                      <tr className="border-b border-white/20 text-[10px] font-bold uppercase">
                        <th className="p-1">ዕቃ</th>
                        <th className="p-1 text-center">ቀሪ</th>
                        <th className="p-1 text-right">ዋጋ</th>
                      </tr>
                    </thead>
                    <tbody>
                      {debts.map((d, i) => {
                        const sItem = store.find(item => item.code === d.itemCode);
                        const name = sItem ? sItem.name : d.itemCode;
                        return (
                          <tr key={i} className="border-b border-white/5 font-semibold text-white/90">
                            <td className="p-1">{name}</td>
                            <td className="p-1 text-center">{d.qty}</td>
                            <td className="p-1 text-right">{formatCurrency(d.qty * d.price)}</td>
                          </tr>
                        );
                      })}
                      {debts.length === 0 && (
                        <tr>
                          <td colSpan={3} className="p-4 text-center text-orange-200 font-bold italic">
                            ምንም ቀሪ እዳ የለም
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>

                {/* Send complaint form */}
                <div className="bg-black/30 p-3 rounded-2xl border border-white/10 space-y-2">
                  <span className="block text-[10px] font-extrabold uppercase tracking-wide text-orange-200">
                    ⚠️ የዕቃ ቁጥር ልዩነት ወይም ቅሬታ ማቅረቢያ
                  </span>
                  <div className="grid grid-cols-2 gap-2">
                    <select
                      value={complaintItem}
                      onChange={(e) => setComplaintItem(e.target.value)}
                      className="p-1.5 rounded-xl border border-white/15 bg-black/20 text-xs font-semibold text-white focus:outline-none focus:border-white"
                    >
                      <option value="" className="text-slate-800">-- ዕቃ ይምረጡ --</option>
                      {debts.map((d, i) => {
                        const sItem = store.find(item => item.code === d.itemCode);
                        return (
                          <option key={i} value={d.itemCode} className="text-slate-800">
                            {sItem ? sItem.name : d.itemCode}
                          </option>
                        );
                      })}
                    </select>
                    <input
                      type="number"
                      placeholder="የተሳሳተ ብዛት"
                      value={complaintQtyVal}
                      onChange={(e) => setComplaintQtyVal(e.target.value)}
                      className="p-1.5 rounded-xl border border-white/15 bg-black/20 text-xs font-semibold text-white placeholder-white/50 text-center"
                    />
                  </div>
                  <button
                    onClick={handleSendComplaint}
                    className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-2 rounded-xl text-[10px] shadow-md shadow-red-950/25 cursor-pointer"
                  >
                    ለባለቤት ቅሬታ ላክ
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Export card */}
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-4 border border-white/15 flex flex-col justify-between">
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-orange-100">አጠቃላይ ሽያጭ ታሪክ</span>
              <p className="text-xs text-white/95 mt-1 font-semibold">የእርስዎን የዛሬና ያለፉትን የሽያጭ ዝርዝሮች በኤክሴል ማውረድ ይችላሉ።</p>
            </div>
            <button
              onClick={handleExportMySales}
              className="mt-4 bg-white/20 hover:bg-white/30 text-white font-black py-2.5 rounded-xl text-xs cursor-pointer border border-white/15 shadow flex items-center justify-center gap-1.5 transition-all"
            >
              <Download size={14} /> የሽያጭ ፋይል አውርድ (.xlsx)
            </button>
          </div>
        </div>
      </div>

      {/* ADD ORDER TO TABLE FORM */}
      <div className="bg-white p-5 rounded-3xl border border-slate-100 shadow-sm space-y-4">
        <h3 className="font-extrabold text-slate-800 text-sm flex items-center gap-1.5">
          <Plus size={18} className="text-orange-500" /> ለጠረጴዛ አዲስ ትዕዛዝ ማዘዣ ፎርም
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 bg-slate-50 p-4 rounded-2xl border">
          <div>
            <label className="block text-[10px] font-bold text-slate-500 mb-1 uppercase">ጠረጴዛ ቁጥር (1-30)</label>
            <input
              type="number"
              placeholder="ለምሳሌ 5"
              min="1"
              max="30"
              value={tableInput}
              onChange={(e) => setTableInput(e.target.value)}
              className="w-full border p-2.5 rounded-xl text-xs font-semibold bg-white text-center focus:outline-none"
            />
          </div>

          <div className="sm:col-span-2">
            <label className="block text-[10px] font-bold text-slate-500 mb-1 uppercase">የአገልግሎት/ዕቃ አይነት</label>
            <select
              value={selectedCode}
              onChange={(e) => setSelectedCode(e.target.value)}
              className="w-full border p-2.5 rounded-xl text-xs font-bold bg-white focus:outline-none"
            >
              <option value="">-- ምግቦችና መጠጦች ይምረጡ --</option>
              {store.map(i => (
                <option key={i.code} value={i.code}>
                  {i.name} ({formatCurrency(i.price)})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[10px] font-bold text-slate-500 mb-1 uppercase">የእቃዎች ብዛት</label>
            <input
              type="number"
              min="1"
              value={orderQty}
              onChange={(e) => setOrderQty(e.target.value)}
              className="w-full border p-2.5 rounded-xl text-xs font-semibold bg-white text-center focus:outline-none"
            />
          </div>
        </div>

        <button
          onClick={handleAddOrder}
          className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-6 py-3 rounded-2xl text-xs shadow-md shadow-emerald-500/10 cursor-pointer active:scale-98 transition-all"
        >
          ለጠረጴዛ ትዕዛዝ ጨምር
        </button>
      </div>

      {/* ACTIVE TABLES MONITOR & MONITORING */}
      <div className="bg-white p-5 rounded-3xl border border-slate-100 shadow-sm space-y-4">
        <h3 className="font-extrabold text-slate-800 text-sm flex items-center gap-1.5">
          <Clipboard size={18} className="text-orange-500" /> የጠረጴዛዎች ሽያጭና ክፍያ መከታተያ (Tables Monitor)
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {activeTables.map(([tableId, ord]) => {
            const tableTotal = ord.items.reduce((s, item) => s + item.price * item.qty, 0);
            return (
              <div key={tableId} className="border border-slate-100 rounded-2xl shadow-sm p-4 bg-slate-50/50 space-y-3">
                <div className="flex justify-between items-center border-b pb-2">
                  <span className="font-black text-xs text-orange-700">🍽️ ጠረጴዛ {tableId}</span>
                  <span className="text-xs font-black text-emerald-600">{formatCurrency(tableTotal)}</span>
                </div>

                {/* Items breakdown */}
                <div className="overflow-x-auto rounded-xl border bg-white text-[10px]">
                  <table className="min-w-full text-left">
                    <thead className="bg-slate-50 border-b font-extrabold text-slate-500">
                      <tr>
                        <th className="p-2">ዕቃ</th>
                        <th className="p-2 text-center">ብዛት</th>
                        <th className="p-2 text-right">ዋጋ</th>
                        <th className="p-2 text-right">ድምር</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y font-bold">
                      {ord.items.map((item, index) => (
                        <tr key={index}>
                          <td className="p-2 text-slate-800">{item.name}</td>
                          <td className="p-2 text-center text-slate-600">{item.qty}</td>
                          <td className="p-2 text-right">{formatCurrency(item.price)}</td>
                          <td className="p-2 text-right text-green-700">{formatCurrency(item.price * item.qty)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                <button
                  onClick={() => onOpenCheckout(tableId)}
                  className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-2.5 rounded-xl text-xs cursor-pointer shadow transition-all duration-200"
                >
                  🧾 ሂሳብ ዝጋ / Checkout
                </button>
              </div>
            );
          })}
          {activeTables.length === 0 && (
            <div className="col-span-full py-8 text-center text-slate-400 italic font-bold text-xs bg-slate-50 rounded-2xl border border-dashed">
              በእርስዎ መለያ የተያዙ ምንም ክፍት የጠረጴዛ ትዕዛዞች የሉም
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
