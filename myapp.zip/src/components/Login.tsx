import React, { useState, useEffect } from 'react';
import { User, HotelLocation } from '../types';
import { Key, Beer, Utensils, Dices, UserCheck, Eye, EyeOff, MapPin } from 'lucide-react';
import { getDistanceFromLatLonInMeters } from '../utils';

interface LoginProps {
  users: User[];
  hotelLocation: HotelLocation;
  onLoginSuccess: (user: User) => void;
}

export default function Login({ users, hotelLocation, onLoginSuccess }: LoginProps) {
  const [selectedRole, setSelectedRole] = useState<'owner' | 'barman' | 'waiter' | 'game' | 'customer' | null>(null);
  const [selectedUserId, setSelectedUserId] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [error, setError] = useState<string>('');
  const [bypassLocation, setBypassLocation] = useState<boolean>(true);
  const [checkingLocation, setCheckingLocation] = useState<boolean>(false);

  const filteredUsers = users.filter(u => u.role === selectedRole);

  useEffect(() => {
    if (filteredUsers.length > 0) {
      setSelectedUserId(filteredUsers[0].id);
    } else {
      setSelectedUserId('');
    }
    setPassword('');
    setError('');
  }, [selectedRole, users]);

  const handleRoleSelect = (role: 'owner' | 'barman' | 'waiter' | 'game' | 'customer') => {
    setSelectedRole(role);
    if (role === 'customer') {
      setError('');
    }
  };

  const handleLogin = () => {
    if (!selectedRole) return;

    if (selectedRole === 'customer') {
      onLoginSuccess({ id: 'CUST01', name: 'ደንበኛ', role: 'customer' });
      return;
    }

    const user = users.find(u => u.id === selectedUserId);
    if (!user) {
      setError('እባክዎ ተጠቃሚ ይምረጡ');
      return;
    }

    if (password !== user.password) {
      setError('⛔ የተሳሳተ ፓስዎርድ!');
      setPassword('');
      return;
    }

    // Geofencing for Waiter
    if (selectedRole === 'waiter') {
      const lat = hotelLocation.lat;
      const lng = hotelLocation.lng;

      if (!lat || !lng) {
        setError('⚠️ የሆቴሉ ሎኬሽን አልተዘጋጀም! እባክዎ በባለቤት አካውንት ያዘጋጁ።');
        return;
      }

      if (bypassLocation) {
        onLoginSuccess(user);
        return;
      }

      setCheckingLocation(true);
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          (pos) => {
            setCheckingLocation(false);
            const dist = getDistanceFromLatLonInMeters(lat, lng, pos.coords.latitude, pos.coords.longitude);
            if (dist > 100) {
              setError(`⛔ ከሆቴሉ 100 ሜትር ራዲየስ ውስጥ አይደሉም! የአሁን ርቀት: ${Math.round(dist)} ሜትር.`);
            } else {
              onLoginSuccess(user);
            }
          },
          (err) => {
            setCheckingLocation(false);
            setError('📍 የአካባቢ መገኛን ማግኘት አልተቻለም። እባክዎ መገኛውን ይፍቀዱ ወይም Simulation Bypass ይጠቀሙ።');
          },
          { enableHighAccuracy: true, timeout: 5000 }
        );
      } else {
        setCheckingLocation(false);
        onLoginSuccess(user);
      }
    } else {
      onLoginSuccess(user);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 overflow-y-auto">
      <div className="bg-white/95 backdrop-blur-md rounded-3xl p-6 md:p-8 max-w-md w-full shadow-2xl border border-white/20 my-8">
        <div className="text-center mb-6">
          <div className="inline-flex p-4 bg-amber-500/10 rounded-2xl text-amber-500 text-4xl mb-3 animate-pulse">
            🏨
          </div>
          <h1 className="text-2xl font-black text-slate-800 tracking-tight font-display">ዘመናዊ የሆቴል መቆጣጠሪያ</h1>
          <p className="text-xs text-slate-500 mt-1 font-medium">ሚናዎን ይምረጡ እና ወደ ሲስተሙ ይግቡ</p>
        </div>

        {!selectedRole ? (
          <div className="space-y-2.5">
            <button
              onClick={() => handleRoleSelect('owner')}
              className="w-full flex items-center justify-between p-3.5 border-2 border-slate-100 hover:border-amber-500 hover:bg-amber-500/5 rounded-2xl cursor-pointer transition-all duration-200 group text-left"
            >
              <div className="flex items-center gap-3">
                <div className="p-2 bg-amber-100 text-amber-600 rounded-xl group-hover:bg-amber-500 group-hover:text-white transition-colors">
                  <Key size={18} />
                </div>
                <span className="font-bold text-slate-700 text-sm">🔑 ባለቤት</span>
              </div>
              <span className="text-xs font-semibold bg-slate-100 px-2.5 py-1 rounded-full text-slate-500">Owner</span>
            </button>

            <button
              onClick={() => handleRoleSelect('barman')}
              className="w-full flex items-center justify-between p-3.5 border-2 border-slate-100 hover:border-indigo-500 hover:bg-indigo-500/5 rounded-2xl cursor-pointer transition-all duration-200 group text-left"
            >
              <div className="flex items-center gap-3">
                <div className="p-2 bg-indigo-100 text-indigo-600 rounded-xl group-hover:bg-indigo-500 group-hover:text-white transition-colors">
                  <Beer size={18} />
                </div>
                <span className="font-bold text-slate-700 text-sm">🍺 ባርማን</span>
              </div>
              <span className="text-xs font-semibold bg-slate-100 px-2.5 py-1 rounded-full text-slate-500">Barman</span>
            </button>

            <button
              onClick={() => handleRoleSelect('waiter')}
              className="w-full flex items-center justify-between p-3.5 border-2 border-slate-100 hover:border-orange-500 hover:bg-orange-500/5 rounded-2xl cursor-pointer transition-all duration-200 group text-left"
            >
              <div className="flex items-center gap-3">
                <div className="p-2 bg-orange-100 text-orange-600 rounded-xl group-hover:bg-orange-500 group-hover:text-white transition-colors">
                  <Utensils size={18} />
                </div>
                <span className="font-bold text-slate-700 text-sm">🍽️ አስተናጋጅ</span>
              </div>
              <span className="text-xs font-semibold bg-slate-100 px-2.5 py-1 rounded-full text-slate-500">Waiter</span>
            </button>

            <button
              onClick={() => handleRoleSelect('game')}
              className="w-full flex items-center justify-between p-3.5 border-2 border-slate-100 hover:border-purple-500 hover:bg-purple-500/5 rounded-2xl cursor-pointer transition-all duration-200 group text-left"
            >
              <div className="flex items-center gap-3">
                <div className="p-2 bg-purple-100 text-purple-600 rounded-xl group-hover:bg-purple-500 group-hover:text-white transition-colors">
                  <Dices size={18} />
                </div>
                <span className="font-bold text-slate-700 text-sm">🎮 ካራንቡላ አጫዋች</span>
              </div>
              <span className="text-xs font-semibold bg-slate-100 px-2.5 py-1 rounded-full text-slate-500">Game</span>
            </button>

            <button
              onClick={() => handleRoleSelect('customer')}
              className="w-full flex items-center justify-between p-3.5 border-2 border-slate-100 hover:border-emerald-500 hover:bg-emerald-500/5 rounded-2xl cursor-pointer transition-all duration-200 group text-left"
            >
              <div className="flex items-center gap-3">
                <div className="p-2 bg-emerald-100 text-emerald-600 rounded-xl group-hover:bg-emerald-500 group-hover:text-white transition-colors">
                  <UserCheck size={18} />
                </div>
                <span className="font-bold text-slate-700 text-sm">📱 QR ደንበኛ</span>
              </div>
              <span className="text-xs font-semibold bg-slate-100 px-2.5 py-1 rounded-full text-slate-500">Customer</span>
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="bg-slate-50 p-3 rounded-2xl border border-slate-100 flex items-center justify-between">
              <span className="text-xs font-bold text-slate-500">ተለይቶ የተመረጠ፦</span>
              <span className="text-xs font-bold capitalize text-amber-600 bg-amber-500/10 px-3 py-1 rounded-full">
                {selectedRole}
              </span>
            </div>

            {selectedRole !== 'customer' && (
              <>
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">ተጠቃሚ ይምረጡ</label>
                  <select
                    value={selectedUserId}
                    onChange={(e) => setSelectedUserId(e.target.value)}
                    className="w-full p-3 border-2 border-slate-100 rounded-xl text-sm bg-white font-medium focus:outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20"
                  >
                    {filteredUsers.map((u) => (
                      <option key={u.id} value={u.id}>
                        {u.name} ({u.id})
                      </option>
                    ))}
                    {filteredUsers.length === 0 && <option value="">ምንም ተጠቃሚ አልተገኘም</option>}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">ፓስዎርድ (4 አሃዝ)</label>
                  <div className="relative">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={password}
                      onChange={(e) => setPassword(e.target.value.slice(0, 4))}
                      maxLength={4}
                      inputMode="numeric"
                      placeholder="ለምሳሌ 1234"
                      className="w-full p-3 pr-12 border-2 border-slate-100 rounded-xl text-sm bg-white font-mono focus:outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 focus:outline-none"
                    >
                      {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                    </button>
                  </div>
                </div>

                {selectedRole === 'waiter' && (
                  <div className="flex items-center gap-2 bg-orange-50 border border-orange-100 p-3 rounded-2xl">
                    <input
                      type="checkbox"
                      id="bypassLocation"
                      checked={bypassLocation}
                      onChange={(e) => setBypassLocation(e.target.checked)}
                      className="rounded text-orange-600 focus:ring-orange-500 h-4 w-4"
                    />
                    <label htmlFor="bypassLocation" className="text-xs font-semibold text-orange-800 select-none cursor-pointer">
                      📍 የአካባቢ መቆጣጠሪያውን አሳልፍ (Simulation Bypass)
                    </label>
                  </div>
                )}
              </>
            )}

            {error && <div className="text-xs font-bold text-red-600 bg-red-50 p-3 rounded-xl border border-red-100">{error}</div>}

            <button
              onClick={handleLogin}
              disabled={checkingLocation}
              className="w-full bg-amber-500 hover:bg-amber-600 text-white p-3.5 rounded-2xl font-bold text-sm shadow-md shadow-amber-500/10 cursor-pointer hover:shadow-lg hover:shadow-amber-500/20 active:scale-98 transition-all disabled:opacity-50"
            >
              {checkingLocation ? '📍 አካባቢ በመፈተሽ ላይ...' : selectedRole === 'customer' ? '📱 እንደ ደንበኛ ግባ' : 'ግባ'}
            </button>

            <button
              onClick={() => setSelectedRole(null)}
              className="w-full text-xs font-bold text-slate-500 hover:text-slate-800 underline block text-center"
            >
              ወደ ሚና ምርጫ ተመለስ
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
