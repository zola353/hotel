export interface User {
  id: string;
  name: string;
  role: 'owner' | 'barman' | 'waiter' | 'game' | 'customer';
  password?: string;
}

export interface StoreItem {
  code: string;
  name: string;
  category: 'ምግብ' | 'መጠጥ' | 'ደረቅ መጠጦች' | string;
  cost: number;
  price: number;
  stock: number;
}

export interface OrderItem {
  code: string;
  name: string;
  price: number;
  qty: number;
  source: 'waiter' | 'customer';
}

export interface TableOrder {
  items: OrderItem[];
  waiterId: string;
  status: 'open' | 'closed';
}

export interface WaiterDebt {
  itemCode: string;
  qty: number;
  price: number;
}

export interface SaleRecord {
  waiterId: string;
  tableId: string | number;
  items: OrderItem[];
  total: number;
  profit: number;
  date: string;
  method: 'Cash' | 'Bank';
  bank: string;
  ref: string;
}

export interface WaiterRating {
  rating: number;
  date: string;
  tableId: number;
  customerName: string;
}

export interface Complaint {
  firebaseKey?: string;
  waiterId: string;
  waiterName: string;
  itemName: string;
  qty: number;
}

export interface Feedback {
  tableId: number;
  message: string;
  time: string;
}

export interface Game {
  id: number;
  customerName: string;
  location: number;
  startTime: string;
  endTime: string | null;
  minutes: number;
  cost: number;
  status: 'active' | 'closed';
}

export interface HotelLocation {
  lat: number | null;
  lng: number | null;
}
