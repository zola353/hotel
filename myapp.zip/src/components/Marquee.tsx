import React from 'react';

interface MarqueeProps {
  text: string;
}

export default function Marquee({ text }: MarqueeProps) {
  return (
    <div className="overflow-hidden white-space-nowrap bg-zinc-800 text-amber-400 py-3 font-semibold text-sm border-b-2 border-amber-500 shadow-inner select-none relative">
      <div className="animate-[marquee_25s_linear_infinite] inline-block whitespace-nowrap pl-full">
        {text}
      </div>
      <style>{`
        @keyframes marquee {
          0% { transform: translate3d(100%, 0, 0); }
          100% { transform: translate3d(-100%, 0, 0); }
        }
      `}</style>
    </div>
  );
}
