import React, { useState } from 'react';
import { User, StoreItem, SaleRecord, WaiterRating, Complaint, Feedback, HotelLocation } from '../types';
import { Key, MessageSquare, Plus, Edit, QrCode, MapPin, Star, TrendingUp, DollarSign, Download, Trash2, Check, Smartphone, Send, AlertTriangle, Beer, Dices } from 'lucide-react';
import { formatCurrency, downloadExcel } from '../utils';
import QRCode from 'qrcode';

interface OwnerDashboardProps {
  users: User[];
  store: StoreItem[];
  waiterDebts: { [waiterId: string]: any[] };
  salesHistory: SaleRecord[];
  waiterRatings: { [waiterId: string]: WaiterRating[] };
  complaints: Complaint[];
  feedbacks: Feedback[];
  hotelLocation: HotelLocation;
  whatsappNumber: string;
  onSaveWhatsApp: (num: string) => void;
  onUpdateMarquee: (text: string) => void;
  onCreateStaff: (name: string, role: 'barman' | 'waiter' | 'game') => void;
  onAddItemToStore: (item: StoreItem) => void;
  onUpdateItemPrice: (code: string, price: number) => void;
  onSaveHotelLocation: (lat: number, lng: number) => void;
  onClearWaiterDebt: (waiterId: string) => void;
  onDismissComplaint: (firebaseKey: string) => void;
  barmanReceivedItems: { [barmanId: string]: { [code: string]: { name: string; qty: number; price: number } } };
  games: any[];
  onHandoverToBarman: (barmanId: string, itemCode: string, qty: number) => void;
  onClearBarmanDebt: (barmanId: string) => void;
  onStartGame: (customerName: string, location: number) => void;
  onEndGame: (gameId: number) => void;
}

export default function OwnerDashboard({
  users,
  store,
  waiterDebts,
  salesHistory,
  waiterRatings,
  complaints,
  feedbacks,
  hotelLocation,
  whatsappNumber,
  onSaveWhatsApp,
  onUpdateMarquee,
  onCreateStaff,
  onAddItemToStore,
  onUpdateItemPrice,
  onSaveHotelLocation,
  onClearWaiterDebt,
  onDismissComplaint,
  barmanReceivedItems,
  games,
  onHandoverToBarman,
  onClearBarmanDebt,
  onStartGame,
  onEndGame,
}: OwnerDashboardProps) {
  // Local States for forms
  const [whatsappInput, setWhatsappInput] = useState('');
  const [marqueeInput, setMarqueeInput] = useState('');
  
  // Staff forms
  const [newBarmanName, setNewBarmanName] = useState('');
  const [newWaiterName, setNewWaiterName] = useState('');
  const [newGameName, setNewGameName] = useState('');

  // Barman Handover form
  const [handoverBarmanId, setHandoverBarmanId] = useState('');
  const [handoverCode, setHandoverCode] = useState('');
  const [handoverQty, setHandoverQty] = useState('1');

  // Carambula Game form
  const [gamePlayerName, setGamePlayerName] = useState('');
  const [gameSpot, setGameSpot] = useState('1');

  // Store forms
  const [itemCode, setItemCode] = useState('');
  const [itemName, setItemName] = useState('');
  const [itemCategory, setItemCategory] = useState('ምግብ');
  const [itemCost, setItemCost] = useState('');
  const [itemPrice, setItemPrice] = useState('');
  const [itemStock, setItemStock] = useState('');

  // Price Modal
  const [showPriceModal, setShowPriceModal] = useState(false);
  const [editCode, setEditCode] = useState('');
  const [editPrice, setEditPrice] = useState('');

  // Location form
  const [latInput, setLatInput] = useState(hotelLocation.lat?.toString() || '');
  const [lngInput, setLngInput] = useState(hotelLocation.lng?.toString() || '');

  // Report filters
  const [profitFilter, setProfitFilter] = useState<'all' | 'daily' | 'weekly' | 'monthly' | 'yearly'>('all');

  // QR Modal
  const [showQrModal, setShowQrModal] = useState(false);
  const [qrUrl, setQrUrl] = useState('');
  const [qrLabel, setQrLabel] = useState('');

  // Sections toggle state
  const [openSection, setOpenSection] = useState<{ [key: string]: boolean }>({
    store: false,
    qr: false,
    location: false,
    performance: true,
    profit: true,
    settlement: true,
    barmanHandover: true,
    gamesController: true,
  });

  const toggleSection = (sec: string) => {
    setOpenSection(prev => ({ ...prev, [sec]: !prev[sec] }));
  };

  // Staff creation
  const handleCreateStaff = (role: 'barman' | 'waiter' | 'game') => {
    let name = '';
    if (role === 'barman') { name = newBarmanName; setNewBarmanName(''); }
    if (role === 'waiter') { name = newWaiterName; setNewWaiterName(''); }
    if (role === 'game') { name = newGameName; setNewGameName(''); }

    if (!name.trim()) return alert('ስም ያስገቡ');
    onCreateStaff(name.trim(), role);
  };

  // Barman Handover Submit
  const handleHandoverSubmit = () => {
    if (!handoverBarmanId || !handoverCode || !handoverQty) {
      return alert('እባክዎ ሙሉ መረጃዎችን ይሙሉ!');
    }
    const qty = parseInt(handoverQty);
    if (isNaN(qty) || qty <= 0) return alert('ትክክለኛ የቁጥር መጠን ያስገቡ');

    const sItem = store.find(i => i.code === handoverCode);
    if (!sItem) return alert('እቃው በስቶር ውስጥ አልተገኘም!');
    if (sItem.stock < qty) return alert(`በቂ ቀሪ የለም! በስቶር ውስጥ ያለው ቀሪ መጠን: ${sItem.stock}`);

    onHandoverToBarman(handoverBarmanId, handoverCode, qty);
    setHandoverQty('1');
    alert('✅ እቃው በተሳካ ሁኔታ ለባርማኑ ተላልፏል!');
  };

  // Carambula Game Start Submit
  const handleStartGameSubmit = () => {
    if (!gamePlayerName.trim()) {
      return alert('እባክዎ የአጫዋቹን ስም ያስገቡ!');
    }
    const spotNum = parseInt(gameSpot);
    if (isNaN(spotNum) || spotNum <= 0) return alert('ትክክለኛ ቦታ ያስገቡ');

    onStartGame(gamePlayerName.trim(), spotNum);
    setGamePlayerName('');
    alert('🎮 የካራንቡላ ጨዋታ በተሳካ ሁኔታ ተጀምሯል!');
  };

  // Add store item
  const handleAddItem = () => {
    if (!itemCode || !itemName || !itemCost || !itemPrice) {
      return alert('እባክዎ ሙሉ መረጃ ያስገቡ');
    }
    onAddItemToStore({
      code: itemCode.trim().toUpperCase(),
      name: itemName.trim(),
      category: itemCategory,
      cost: parseFloat(itemCost),
      price: parseFloat(itemPrice),
      stock: parseInt(itemStock) || 0,
    });
    setItemCode('');
    setItemName('');
    setItemCost('');
    setItemPrice('');
    setItemStock('');
    alert('አዲስ ዕቃ ገብቷል!');
  };

  // Price Modal update
  const handlePriceUpdate = () => {
    if (!editCode || !editPrice) return alert('መረጃ ያስገቡ');
    onUpdateItemPrice(editCode, parseFloat(editPrice));
    setShowPriceModal(false);
    setEditPrice('');
    alert('ዋጋ ተሻሽሏል!');
  };

  // Geolocation save
  const handleSaveLocation = () => {
    const lat = parseFloat(latInput);
    const lng = parseFloat(lngInput);
    if (isNaN(lat) || isNaN(lng)) return alert('ትክክለኛ ቁጥር ያስገቡ');
    onSaveHotelLocation(lat, lng);
    alert('የሆቴል ሎኬሽን ተቀምጧል!');
  };

  // QR Code generator
  const handleGenerateQr = async (tableNum: number) => {
    const link = `${window.location.origin}${window.location.pathname}?customer=1&table=${tableNum}`;
    try {
      const url = await QRCode.toDataURL(link, { width: 250, margin: 2 });
      setQrUrl(url);
      setQrLabel(`ጠረጴዛ ${tableNum}`);
      setShowQrModal(true);
    } catch (err) {
      console.error(err);
    }
  };

  // Performance calculations
  const calculatePerformance = () => {
    const now = new Date();
    const todayStr = now.toDateString();
    const weekStart = new Date(now);
    weekStart.setDate(now.getDate() - now.getDay());
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);

    const waiters = users.filter(u => u.role === 'waiter');
    const perfData: { [id: string]: { name: string; todaySales: number; weekSales: number; monthSales: number; todayRates: number[]; weekRates: number[]; monthRates: number[] } } = {};

    waiters.forEach(w => {
      perfData[w.id] = { name: w.name, todaySales: 0, weekSales: 0, monthSales: 0, todayRates: [], weekRates: [], monthRates: [] };
    });

    salesHistory.forEach(sale => {
      const sDate = new Date(sale.date);
      if (!perfData[sale.waiterId]) return;

      if (sDate.toDateString() === todayStr) perfData[sale.waiterId].todaySales += sale.total;
      if (sDate >= weekStart) perfData[sale.waiterId].weekSales += sale.total;
      if (sDate >= monthStart) perfData[sale.waiterId].monthSales += sale.total;
    });

    for (const wid in waiterRatings) {
      const ratings = waiterRatings[wid] || [];
      if (!perfData[wid]) continue;

      ratings.forEach(r => {
        const rDate = new Date(r.date);
        if (rDate.toDateString() === todayStr) perfData[wid].todayRates.push(r.rating);
        if (rDate >= weekStart) perfData[wid].weekRates.push(r.rating);
        if (rDate >= monthStart) perfData[wid].monthRates.push(r.rating);
      });
    }

    const avg = (arr: number[]) => arr.length ? (arr.reduce((a, b) => a + b, 0) / arr.length) : 0;

    return { perfData, avg };
  };

  const { perfData, avg } = calculatePerformance();

  // Sort best performers
  const bestTodaySales = Object.values(perfData).sort((a, b) => b.todaySales - a.todaySales)[0];
  const bestWeekSales = Object.values(perfData).sort((a, b) => b.weekSales - a.weekSales)[0];
  const bestMonthSales = Object.values(perfData).sort((a, b) => b.monthSales - a.monthSales)[0];

  const bestTodayRating = Object.values(perfData).sort((a, b) => avg(b.todayRates) - avg(a.todayRates))[0];
  const bestWeekRating = Object.values(perfData).sort((a, b) => avg(b.weekRates) - avg(a.weekRates))[0];
  const bestMonthRating = Object.values(perfData).sort((a, b) => avg(b.monthRates) - avg(a.monthRates))[0];

  // Profit Report data based on filter
  const getFilteredProfitReport = () => {
    const now = new Date();
    const todayStr = now.toDateString();
    let daily = 0, weekly = 0, monthly = 0, yearly = 0;
    const summary: { [code: string]: { name: string; cost: number; price: number; qty: number; profit: number } } = {};

    salesHistory.forEach(sale => {
      const sDate = new Date(sale.date);
      const diffDays = Math.ceil(Math.abs(now.getTime() - sDate.getTime()) / (1000 * 60 * 60 * 24));
      
      yearly += sale.profit;
      if (diffDays <= 30) monthly += sale.profit;
      if (diffDays <= 7) weekly += sale.profit;
      if (sDate.toDateString() === todayStr) daily += sale.profit;

      const isMatch = profitFilter === 'all' ||
        (profitFilter === 'daily' && sDate.toDateString() === todayStr) ||
        (profitFilter === 'weekly' && diffDays <= 7) ||
        (profitFilter === 'monthly' && diffDays <= 30) ||
        (profitFilter === 'yearly' && sDate.getFullYear() === now.getFullYear());

      if (isMatch) {
        sale.items.forEach(item => {
          if (!summary[item.code]) {
            const sItem = store.find(i => i.code === item.code);
            summary[item.code] = {
              name: item.name,
              cost: sItem ? sItem.cost : item.price,
              price: item.price,
              qty: 0,
              profit: 0
            };
          }
          summary[item.code].qty += item.qty;
          summary[item.code].profit += (summary[item.code].price - summary[item.code].cost) * item.qty;
        });
      }
    });

    return { daily, weekly, monthly, yearly, tableData: Object.values(summary) };
  };

  const { daily, weekly, monthly, yearly, tableData } = getFilteredProfitReport();

  // Excel exporter
  const handleExportProfit = () => {
    const formatted = tableData.map((d, i) => ({
      'ተ.ቁ': i + 1,
      'አገልግሎት': d.name,
      'ኮስት': d.cost,
      'ሽያጭ ዋጋ': d.price,
      'ብዛት': d.qty,
      'ትርፍ (ብር)': d.profit
    }));
    downloadExcel(formatted, `Hotel_Profit_Report_${profitFilter}`);
  };

  return (
    <div className="space-y-6">
      {/* HEADER CARD */}
      <div className="bg-white p-5 md:p-6 rounded-3xl shadow-md border-t-4 border-amber-500">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-xl md:text-2xl font-black text-slate-800 tracking-tight font-display flex items-center gap-2">
              <Key className="text-amber-500 animate-pulse" /> 🔑 የባለቤት መቆጣጠሪያ ፓነል
            </h2>
            <p className="text-xs text-slate-500 font-medium mt-1">የሆቴሉ አጠቃላይ ስራ፣ ሰራተኞች እና ሂሳብ መቆጣጠሪያ</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <span className="text-xs font-bold bg-amber-50 text-amber-700 border border-amber-100 px-3 py-1.5 rounded-full">
              ባለቤት (Owner)
            </span>
          </div>
        </div>
      </div>

      {/* QUICK ACTIONS SETTINGS (WHATSAPP & MARQUEE) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* WhatsApp Card */}
        <div className="bg-white p-5 rounded-3xl border border-slate-100 shadow-sm space-y-3">
          <h3 className="font-bold text-slate-700 text-sm flex items-center gap-2">
            <Smartphone className="text-emerald-500" /> የሆቴል ዋትስአፕ ቁጥር ማስተካከያ
          </h3>
          <div className="flex gap-2">
            <input
              type="text"
              placeholder="ለምሳሌ 251911234567"
              value={whatsappInput}
              onChange={(e) => setWhatsappInput(e.target.value)}
              className="border border-slate-200 p-2.5 rounded-xl w-full text-xs font-semibold focus:outline-none focus:border-emerald-500 bg-slate-50"
            />
            <button
              onClick={() => {
                if (!whatsappInput.trim()) return alert('እባክዎ ቁጥር ያስገቡ');
                onSaveWhatsApp(whatsappInput.trim());
                setWhatsappInput('');
                alert('ዋትስአፕ ቁጥር ተቀምጧል!');
              }}
              className="bg-emerald-600 hover:bg-emerald-700 text-white px-5 py-2.5 rounded-xl text-xs font-bold shadow-md cursor-pointer transition-all shrink-0"
            >
              አስቀምጥ
            </button>
          </div>
          {whatsappNumber && (
            <p className="text-xs font-bold text-emerald-700 bg-emerald-50 border border-emerald-100 p-2 rounded-xl flex items-center gap-1.5">
              <Check size={14} /> የተቀመጠ ዋትስአፕ ቁጥር፦ {whatsappNumber}
            </p>
          )}
        </div>

        {/* Marquee Card */}
        <div className="bg-white p-5 rounded-3xl border border-slate-100 shadow-sm space-y-3">
          <h3 className="font-bold text-slate-700 text-sm flex items-center gap-2">
            <Send className="text-amber-500" /> የሆቴል ማስታወቂያ (Marquee)
          </h3>
          <div className="flex gap-2">
            <input
              type="text"
              placeholder="በሆቴሉ በላይኛው ክፍል የሚሮጥ ፅሁፍ..."
              value={marqueeInput}
              onChange={(e) => setMarqueeInput(e.target.value)}
              className="border border-slate-200 p-2.5 rounded-xl w-full text-xs font-semibold focus:outline-none focus:border-amber-500 bg-slate-50"
            />
            <button
              onClick={() => {
                if (!marqueeInput.trim()) return alert('ፅሁፍ ያስገቡ');
                onUpdateMarquee(marqueeInput.trim());
                setMarqueeInput('');
                alert('ማስታወቂያው ተቀይሯል!');
              }}
              className="bg-amber-500 hover:bg-amber-600 text-white px-5 py-2.5 rounded-xl text-xs font-bold shadow-md cursor-pointer transition-all shrink-0"
            >
              ለጥፍ
            </button>
          </div>
        </div>
      </div>

      {/* STAFF CREATION PANELS */}
      <div className="bg-white p-5 rounded-3xl border border-slate-100 shadow-sm">
        <h3 className="font-bold text-slate-700 text-sm mb-3">👤 ሰራተኛ መመዝገቢያና የፓስኮድ መፍጠሪያ</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Barman */}
          <div className="bg-slate-50 border border-slate-100 p-4 rounded-2xl flex flex-col justify-between gap-3">
            <div>
              <h4 className="text-xs font-extrabold text-indigo-700 uppercase tracking-wider">👤 አዲስ ባርማን</h4>
              <p className="text-[10px] text-slate-400 font-medium">ለመጠጥ ርክክብ እና ስቶር መቆጣጠሪያ</p>
            </div>
            <div className="flex gap-1.5">
              <input
                type="text"
                placeholder="ስም"
                value={newBarmanName}
                onChange={(e) => setNewBarmanName(e.target.value)}
                className="border border-slate-200 p-2 rounded-xl text-xs font-semibold bg-white w-full focus:outline-none focus:border-indigo-500"
              />
              <button
                onClick={() => handleCreateStaff('barman')}
                className="bg-indigo-600 hover:bg-indigo-700 text-white px-3 py-2 rounded-xl text-xs font-bold shrink-0 shadow cursor-pointer"
              >
                ፍጠር
              </button>
            </div>
          </div>

          {/* Waiter */}
          <div className="bg-slate-50 border border-slate-100 p-4 rounded-2xl flex flex-col justify-between gap-3">
            <div>
              <h4 className="text-xs font-extrabold text-orange-700 uppercase tracking-wider">👤 አዲስ አስተናጋጅ</h4>
              <p className="text-[10px] text-slate-400 font-medium">ለጠረጴዛ ትዕዛዝ እና ክፍያ መሰብሰቢያ</p>
            </div>
            <div className="flex gap-1.5">
              <input
                type="text"
                placeholder="ስም"
                value={newWaiterName}
                onChange={(e) => setNewWaiterName(e.target.value)}
                className="border border-slate-200 p-2 rounded-xl text-xs font-semibold bg-white w-full focus:outline-none focus:border-orange-500"
              />
              <button
                onClick={() => handleCreateStaff('waiter')}
                className="bg-orange-500 hover:bg-orange-600 text-white px-3 py-2 rounded-xl text-xs font-bold shrink-0 shadow cursor-pointer"
              >
                ፍጠር
              </button>
            </div>
          </div>

          {/* Game */}
          <div className="bg-slate-50 border border-slate-100 p-4 rounded-2xl flex flex-col justify-between gap-3">
            <div>
              <h4 className="text-xs font-extrabold text-purple-700 uppercase tracking-wider">🎮 አዲስ ካራንቡላ አጫዋች</h4>
              <p className="text-[10px] text-slate-400 font-medium">የጨዋታ ክፍያዎችን ለመከታተል</p>
            </div>
            <div className="flex gap-1.5">
              <input
                type="text"
                placeholder="ስም"
                value={newGameName}
                onChange={(e) => setNewGameName(e.target.value)}
                className="border border-slate-200 p-2 rounded-xl text-xs font-semibold bg-white w-full focus:outline-none focus:border-purple-500"
              />
              <button
                onClick={() => handleCreateStaff('game')}
                className="bg-purple-600 hover:bg-purple-700 text-white px-3 py-2 rounded-xl text-xs font-bold shrink-0 shadow cursor-pointer"
              >
                ፍጠር
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* ACCORDION SECTIONS */}

      {/* 1. STORE CONTAINER */}
      <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
        <div
          onClick={() => toggleSection('store')}
          className="p-4 md:p-5 font-bold text-slate-800 flex justify-between items-center bg-slate-50 border-b border-slate-100 cursor-pointer select-none"
        >
          <span className="flex items-center gap-2">📦 የአገልግሎት/ዕቃ መመዝገቢያ ስቶር ({store.length} ዕቃዎች)</span>
          <span className="text-[11px] bg-slate-200 px-3 py-1 rounded-full font-bold">መንካት</span>
        </div>
        
        {openSection.store && (
          <div className="p-4 space-y-4">
            <div className="grid grid-cols-2 md:grid-cols-6 gap-2 bg-slate-50 p-3 rounded-2xl border border-slate-100">
              <input
                type="text"
                placeholder="ኮድ (ለምሳሌ B3)"
                value={itemCode}
                onChange={(e) => setItemCode(e.target.value)}
                className="border border-slate-200 p-2 rounded-xl text-xs font-semibold bg-white focus:outline-none"
              />
              <input
                type="text"
                placeholder="የእቃ ስም"
                value={itemName}
                onChange={(e) => setItemName(e.target.value)}
                className="border border-slate-200 p-2 rounded-xl text-xs font-semibold bg-white focus:outline-none"
              />
              <select
                value={itemCategory}
                onChange={(e) => setItemCategory(e.target.value)}
                className="border border-slate-200 p-2 rounded-xl text-xs font-semibold bg-white focus:outline-none"
              >
                <option value="ምግብ">ምግብ</option>
                <option value="መጠጥ">መጠጥ</option>
                <option value="ደረቅ መጠጦች">ደረቅ መጠጦች</option>
              </select>
              <input
                type="number"
                placeholder="የመግዣ ዋጋ (ኮስት)"
                value={itemCost}
                onChange={(e) => setItemCost(e.target.value)}
                className="border border-slate-200 p-2 rounded-xl text-xs font-semibold bg-white focus:outline-none"
              />
              <input
                type="number"
                placeholder="የመሸጫ ዋጋ (ፕራይስ)"
                value={itemPrice}
                onChange={(e) => setItemPrice(e.target.value)}
                className="border border-slate-200 p-2 rounded-xl text-xs font-semibold bg-white focus:outline-none"
              />
              <input
                type="number"
                placeholder="ክምችት (ብዛት)"
                value={itemStock}
                onChange={(e) => setItemStock(e.target.value)}
                className="border border-slate-200 p-2 rounded-xl text-xs font-semibold bg-white focus:outline-none"
              />
            </div>

            <div className="flex flex-wrap gap-2">
              <button
                onClick={handleAddItem}
                className="bg-emerald-600 hover:bg-emerald-700 text-white px-5 py-2.5 rounded-xl font-bold text-xs shadow cursor-pointer transition-all"
              >
                ወደ ስቶር አስገባ
              </button>
              <button
                onClick={() => setShowPriceModal(true)}
                className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2.5 rounded-xl font-bold text-xs shadow cursor-pointer transition-all flex items-center gap-1.5"
              >
                <Edit size={14} /> የዋጋ ማሻሻያ
              </button>
            </div>

            <div className="overflow-x-auto rounded-2xl border border-slate-100">
              <table className="min-w-full bg-white text-xs text-left">
                <thead className="bg-slate-50 border-b border-slate-100 font-extrabold text-slate-700">
                  <tr>
                    <th className="p-3">ኮድ</th>
                    <th className="p-3">ስም</th>
                    <th className="p-3">ምድብ</th>
                    <th className="p-3">የመግዣ (ኮስት)</th>
                    <th className="p-3">የመሸጫ ዋጋ</th>
                    <th className="p-3">ክምችት</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium">
                  {store.map((item) => (
                    <tr key={item.code} className="hover:bg-slate-50/50">
                      <td className="p-3 font-mono font-bold text-slate-600">{item.code}</td>
                      <td className="p-3 font-bold text-slate-800">{item.name}</td>
                      <td className="p-3">
                        <span className="bg-slate-100 text-slate-600 px-2.5 py-1 rounded-full text-[10px] font-bold">
                          {item.category}
                        </span>
                      </td>
                      <td className="p-3 font-semibold">{formatCurrency(item.cost)}</td>
                      <td className="p-3 font-bold text-emerald-600">{formatCurrency(item.price)}</td>
                      <td className={`p-3 font-extrabold ${item.stock < 10 ? 'text-red-500 animate-pulse' : 'text-slate-800'}`}>
                        {item.stock}
                      </td>
                    </tr>
                  ))}
                  {store.length === 0 && (
                    <tr>
                      <td colSpan={6} className="p-6 text-center text-slate-400 italic font-bold">
                        በስቶር ውስጥ ምንም ዕቃ የለም
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* 2. TABLE QR CODE GENERATOR */}
      <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
        <div
          onClick={() => toggleSection('qr')}
          className="p-4 md:p-5 font-bold text-slate-800 flex justify-between items-center bg-slate-50 border-b border-slate-100 cursor-pointer select-none"
        >
          <span className="flex items-center gap-2">🔗 የጠረጴዛ ሊንክ እና QR ፈጣሪ (30 ጠረጴዛዎች)</span>
          <span className="text-[11px] bg-slate-200 px-3 py-1 rounded-full font-bold">መንካት</span>
        </div>

        {openSection.qr && (
          <div className="p-4 space-y-4">
            <p className="text-xs text-slate-500 font-medium">
              እያንዳንዱ ሊንክ ሲነካ ደንበኛው በቀጥታ ጠረጴዛውን መርጦ ማዘዝ እና አስተናጋጁን ደረጃ መስጠት ይችላል።
            </p>
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-3 max-h-96 overflow-y-auto p-1 font-sans">
              {Array.from({ length: 30 }, (_, i) => i + 1).map((tableNum) => {
                const link = `${window.location.origin}${window.location.pathname}?customer=1&table=${tableNum}`;
                return (
                  <div key={tableNum} className="flex flex-col items-center p-3 bg-slate-50 border border-slate-100 rounded-2xl shadow-sm text-center">
                    <span className="font-extrabold text-slate-800 text-sm">ጠረጴዛ {tableNum}</span>
                    <a
                      href={link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-[10px] text-blue-600 hover:underline font-bold mt-1.5 break-all line-clamp-1 border border-blue-100 px-2 py-1 rounded bg-blue-50/50"
                    >
                      ማዘዣ ሊንክ
                    </a>
                    <button
                      onClick={() => handleGenerateQr(tableNum)}
                      className="mt-2.5 text-[10px] font-bold bg-slate-800 hover:bg-slate-900 text-white px-3 py-1.5 rounded-xl cursor-pointer w-full flex items-center justify-center gap-1"
                    >
                      <QrCode size={12} /> QR ኮድ
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* 3. HOTEL LOCATION CHECKER SETTING */}
      <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
        <div
          onClick={() => toggleSection('location')}
          className="p-4 md:p-5 font-bold text-slate-800 flex justify-between items-center bg-slate-50 border-b border-slate-100 cursor-pointer select-none"
        >
          <span className="flex items-center gap-2">📍 የሆቴሉን ጂፒኤስ መገኛ መመዝገቢያ (Geofence Location)</span>
          <span className="text-[11px] bg-slate-200 px-3 py-1 rounded-full font-bold">መንካት</span>
        </div>

        {openSection.location && (
          <div className="p-4 space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 bg-slate-50 p-4 rounded-2xl border">
              <div>
                <label className="block text-[10px] font-extrabold text-slate-500 mb-1 uppercase">ኬክሮስ (Latitude)</label>
                <input
                  type="text"
                  placeholder="ለምሳሌ 9.0300"
                  value={latInput}
                  onChange={(e) => setLatInput(e.target.value)}
                  className="w-full border p-2.5 rounded-xl text-xs font-semibold bg-white"
                />
              </div>
              <div>
                <label className="block text-[10px] font-extrabold text-slate-500 mb-1 uppercase">ቀኝ (Longitude)</label>
                <input
                  type="text"
                  placeholder="ለምሳሌ 38.7400"
                  value={lngInput}
                  onChange={(e) => setLngInput(e.target.value)}
                  className="w-full border p-2.5 rounded-xl text-xs font-semibold bg-white"
                />
              </div>
              <div className="flex items-end">
                <button
                  onClick={handleSaveLocation}
                  className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2.5 rounded-xl font-bold text-xs shadow cursor-pointer w-full"
                >
                  አስተካክል
                </button>
              </div>
            </div>
            {hotelLocation.lat && hotelLocation.lng ? (
              <p className="text-xs font-bold text-slate-600 bg-emerald-50 p-3 rounded-xl border border-emerald-100 inline-flex items-center gap-1.5">
                ✅ የአሁን የሆቴሉ መገኛ የተመዘገበው ኬክሮስ: {hotelLocation.lat}, ቀኝ: {hotelLocation.lng} ላይ ነው።
              </p>
            ) : (
              <p className="text-xs font-bold text-red-500 italic bg-red-50 p-3 rounded-xl border border-red-100">
                ⚠️ የአሁን መገኛ አልተመዘገበም! እባክዎ አስተናጋጆች ከመገኛ ውጪ መሆናቸውን ለመቆጣጠር መገኛውን ይመዝግቡ።
              </p>
            )}
          </div>
        )}
      </div>

      {/* 4. PERFORMANCE EVALUATION */}
      <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
        <div
          onClick={() => toggleSection('performance')}
          className="p-4 md:p-5 font-bold text-slate-800 flex justify-between items-center bg-slate-50 border-b border-slate-100 cursor-pointer select-none"
        >
          <span className="flex items-center gap-2">⭐ የአስተናጋጆች የስራ እንቅስቃሴና የደንበኛ እርካታ ምዘና (ኮኮቦች)</span>
          <span className="text-[11px] bg-slate-200 px-3 py-1 rounded-full font-bold">መንካት</span>
        </div>

        {openSection.performance && (
          <div className="p-4 space-y-4">
            {/* Best performing blocks */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {/* Day Star */}
              <div className="bg-amber-50/50 p-3.5 rounded-2xl border border-amber-200 shadow-sm flex items-center gap-3">
                <div className="p-2.5 bg-amber-500 text-white rounded-xl">
                  <Star size={18} fill="currentColor" />
                </div>
                <div>
                  <span className="block text-[10px] text-slate-400 font-bold uppercase">የዛሬ ኮከብ አስተናጋጅ</span>
                  <span className="text-xs font-black text-amber-900 block mt-0.5">
                    {bestTodaySales && bestTodaySales.todaySales > 0 ? `${bestTodaySales.name} (${formatCurrency(bestTodaySales.todaySales)})` : 'አልተገኘም'}
                  </span>
                </div>
              </div>

              {/* Week Star */}
              <div className="bg-blue-50/50 p-3.5 rounded-2xl border border-blue-200 shadow-sm flex items-center gap-3">
                <div className="p-2.5 bg-blue-500 text-white rounded-xl">
                  <Star size={18} fill="currentColor" />
                </div>
                <div>
                  <span className="block text-[10px] text-slate-400 font-bold uppercase">የሳምንቱ ኮከብ አስተናጋጅ</span>
                  <span className="text-xs font-black text-blue-900 block mt-0.5">
                    {bestWeekSales && bestWeekSales.weekSales > 0 ? `${bestWeekSales.name} (${formatCurrency(bestWeekSales.weekSales)})` : 'አልተገኘም'}
                  </span>
                </div>
              </div>

              {/* Month Star */}
              <div className="bg-purple-50/50 p-3.5 rounded-2xl border border-purple-200 shadow-sm flex items-center gap-3">
                <div className="p-2.5 bg-purple-500 text-white rounded-xl">
                  <Star size={18} fill="currentColor" />
                </div>
                <div>
                  <span className="block text-[10px] text-slate-400 font-bold uppercase">የወሩ ኮከብ አስተናጋጅ</span>
                  <span className="text-xs font-black text-purple-900 block mt-0.5">
                    {bestMonthSales && bestMonthSales.monthSales > 0 ? `${bestMonthSales.name} (${formatCurrency(bestMonthSales.monthSales)})` : 'አልተገኘም'}
                  </span>
                </div>
              </div>
            </div>

            {/* Ratings stars best */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {/* Rating Day */}
              <div className="bg-amber-50/50 p-3.5 rounded-2xl border border-amber-200 shadow-sm flex items-center gap-3">
                <div className="p-2.5 bg-amber-500/20 text-amber-600 rounded-xl">
                  <Star size={18} fill="currentColor" />
                </div>
                <div>
                  <span className="block text-[10px] text-slate-400 font-bold uppercase">የዛሬ ደንበኛ ምርጥ ኮከብ</span>
                  <span className="text-xs font-black text-amber-900 block mt-0.5">
                    {bestTodayRating && bestTodayRating.todayRates.length ? `${bestTodayRating.name} (አማካይ ${avg(bestTodayRating.todayRates).toFixed(1)} ⭐)` : 'የለም'}
                  </span>
                </div>
              </div>

              {/* Rating Week */}
              <div className="bg-blue-50/50 p-3.5 rounded-2xl border border-blue-200 shadow-sm flex items-center gap-3">
                <div className="p-2.5 bg-blue-500/20 text-blue-600 rounded-xl">
                  <Star size={18} fill="currentColor" />
                </div>
                <div>
                  <span className="block text-[10px] text-slate-400 font-bold uppercase">የሳምንቱ ደንበኛ ምርጥ ኮከብ</span>
                  <span className="text-xs font-black text-blue-900 block mt-0.5">
                    {bestWeekRating && bestWeekRating.weekRates.length ? `${bestWeekRating.name} (አማካይ ${avg(bestWeekRating.weekRates).toFixed(1)} ⭐)` : 'የለም'}
                  </span>
                </div>
              </div>

              {/* Rating Month */}
              <div className="bg-purple-50/50 p-3.5 rounded-2xl border border-purple-200 shadow-sm flex items-center gap-3">
                <div className="p-2.5 bg-purple-500/20 text-purple-600 rounded-xl">
                  <Star size={18} fill="currentColor" />
                </div>
                <div>
                  <span className="block text-[10px] text-slate-400 font-bold uppercase">የወሩ ደንበኛ ምርጥ ኮከብ</span>
                  <span className="text-xs font-black text-purple-900 block mt-0.5">
                    {bestMonthRating && bestMonthRating.monthRates.length ? `${bestMonthRating.name} (አማካይ ${avg(bestMonthRating.monthRates).toFixed(1)} ⭐)` : 'የለም'}
                  </span>
                </div>
              </div>
            </div>

            {/* Performance table */}
            <div className="overflow-x-auto rounded-2xl border border-slate-100">
              <table className="min-w-full bg-white text-xs text-left">
                <thead className="bg-slate-50 border-b border-slate-100 font-extrabold text-slate-700">
                  <tr>
                    <th className="p-3">አስተናጋጅ</th>
                    <th className="p-3">የዛሬ ሽያጭ</th>
                    <th className="p-3">የሳምንቱ ሽያጭ</th>
                    <th className="p-3">የወሩ ሽያጭ</th>
                    <th className="p-3 text-center">የዛሬ ደረጃ (ደንበኛ)</th>
                    <th className="p-3 text-center">የሳምንት ደረጃ (ደንበኛ)</th>
                    <th className="p-3 text-center">የወር ደረጃ (ደንበኛ)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium">
                  {Object.entries(perfData).map(([id, info]) => (
                    <tr key={id} className="hover:bg-slate-50/50">
                      <td className="p-3 font-bold text-slate-800">{info.name}</td>
                      <td className="p-3 font-semibold text-emerald-600">{formatCurrency(info.todaySales)}</td>
                      <td className="p-3 font-semibold text-blue-600">{formatCurrency(info.weekSales)}</td>
                      <td className="p-3 font-semibold text-purple-600">{formatCurrency(info.monthSales)}</td>
                      <td className="p-3 text-center font-bold text-amber-500">
                        {info.todayRates.length ? `${avg(info.todayRates).toFixed(1)} ⭐` : '-'}
                      </td>
                      <td className="p-3 text-center font-bold text-amber-500">
                        {info.weekRates.length ? `${avg(info.weekRates).toFixed(1)} ⭐` : '-'}
                      </td>
                      <td className="p-3 text-center font-bold text-amber-500">
                        {info.monthRates.length ? `${avg(info.monthRates).toFixed(1)} ⭐` : '-'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* 5. PROFIT REPORT CARD */}
      <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
        <div
          onClick={() => toggleSection('profit')}
          className="p-4 md:p-5 font-bold text-slate-800 flex justify-between items-center bg-slate-50 border-b border-slate-100 cursor-pointer select-none"
        >
          <span className="flex items-center gap-2">📈 የሆቴሉ የትርፍና ሽያጭ መገለጫ (ሪፖርት)</span>
          <span className="text-[11px] bg-slate-200 px-3 py-1 rounded-full font-bold">መንካት</span>
        </div>

        {openSection.profit && (
          <div className="p-4 space-y-4">
            {/* Revenue metrics cards */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 text-center">
              <div className="bg-slate-50 p-4 border rounded-2xl">
                <span className="block text-[10px] text-slate-400 font-bold uppercase">የዛሬ ትርፍ</span>
                <span className="text-lg font-black text-emerald-600 mt-1 block">{formatCurrency(daily)}</span>
              </div>
              <div className="bg-slate-50 p-4 border rounded-2xl">
                <span className="block text-[10px] text-slate-400 font-bold uppercase">የሳምንቱ ትርፍ</span>
                <span className="text-lg font-black text-blue-600 mt-1 block">{formatCurrency(weekly)}</span>
              </div>
              <div className="bg-slate-50 p-4 border rounded-2xl">
                <span className="block text-[10px] text-slate-400 font-bold uppercase">የወሩ ትርፍ</span>
                <span className="text-lg font-black text-purple-600 mt-1 block">{formatCurrency(monthly)}</span>
              </div>
              <div className="bg-slate-50 p-4 border rounded-2xl">
                <span className="block text-[10px] text-slate-400 font-bold uppercase">የአመቱ ትርፍ</span>
                <span className="text-lg font-black text-amber-600 mt-1 block">{formatCurrency(yearly)}</span>
              </div>
            </div>

            {/* Profit Filters */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-50 p-3.5 rounded-2xl border">
              <div className="flex items-center gap-2">
                <label className="text-xs font-bold text-slate-500 shrink-0">የጊዜ ማጣሪያ፦</label>
                <select
                  value={profitFilter}
                  onChange={(e: any) => setProfitFilter(e.target.value)}
                  className="p-2 border border-slate-200 rounded-xl text-xs font-bold bg-white focus:outline-none"
                >
                  <option value="all">ሁሉንም ሪፖርቶች አሳይ</option>
                  <option value="daily">የዛሬ ብቻ</option>
                  <option value="weekly">የሳምንት ብቻ</option>
                  <option value="monthly">የወር ብቻ</option>
                  <option value="yearly">የአመት ብቻ</option>
                </select>
              </div>
              <button
                onClick={handleExportProfit}
                className="bg-slate-800 hover:bg-slate-900 text-white px-4 py-2.5 rounded-xl text-xs font-bold shadow flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Download size={14} /> የኤክሴል ሪፖርት አውርድ
              </button>
            </div>

            {/* Profit Report Table */}
            <div className="overflow-x-auto rounded-2xl border border-slate-100">
              <table className="min-w-full bg-white text-xs text-left">
                <thead className="bg-slate-50 border-b border-slate-100 font-extrabold text-slate-700">
                  <tr>
                    <th className="p-3 text-center">ተ.ቁ</th>
                    <th className="p-3">አገልግሎት (የዕቃው ስም)</th>
                    <th className="p-3">የመግዣ ዋጋ (ኮስት)</th>
                    <th className="p-3">የመሸጫ ዋጋ</th>
                    <th className="p-3 text-center">የተሸጠው ብዛት</th>
                    <th className="p-3 text-right">የተገኘው ትርፍ (ብር)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium">
                  {tableData.map((d, i) => (
                    <tr key={i} className="hover:bg-slate-50/50">
                      <td className="p-3 text-center font-mono text-slate-500">{i + 1}</td>
                      <td className="p-3 font-bold text-slate-800">{d.name}</td>
                      <td className="p-3 font-semibold">{formatCurrency(d.cost)}</td>
                      <td className="p-3 font-semibold">{formatCurrency(d.price)}</td>
                      <td className="p-3 text-center font-extrabold text-slate-800">{d.qty}</td>
                      <td className="p-3 font-black text-emerald-600 text-right">{formatCurrency(d.profit)}</td>
                    </tr>
                  ))}
                  {tableData.length === 0 && (
                    <tr>
                      <td colSpan={6} className="p-6 text-center text-slate-400 italic font-bold">
                        በዚህ የጊዜ ገደብ ውስጥ ምንም የሽያጭ መረጃ አልተመዘገበም።
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* 6. SETTLEMENT & DEBT MANAGEMENT */}
      <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
        <div
          onClick={() => toggleSection('settlement')}
          className="p-4 md:p-5 font-bold text-slate-800 flex justify-between items-center bg-slate-50 border-b border-slate-100 cursor-pointer select-none"
        >
          <span className="flex items-center gap-2">📊 የአስተናጋጆች እዳ እና የዕለት ሽያጭ ማመሳከሪያ (ዕዳ ማጽጃ)</span>
          <span className="text-[11px] bg-slate-200 px-3 py-1 rounded-full font-bold">መንካት</span>
        </div>

        {openSection.settlement && (
          <div className="p-4 space-y-4">
            <div className="overflow-x-auto rounded-2xl border border-slate-100">
              <table className="min-w-full bg-white text-xs text-left">
                <thead className="bg-slate-50 border-b border-slate-100 font-extrabold text-slate-700">
                  <tr>
                    <th className="p-3">የአስተናጋጅ መለያ</th>
                    <th className="p-3">ስም</th>
                    <th className="p-3">የዕለት ሽያጭ ድምር</th>
                    <th className="p-3 text-red-500">ያለበት ቀሪ እዳ (ለባር)</th>
                    <th className="p-3 text-center">ሂሳብ ተቀበል/አጽዳ</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium">
                  {users.filter(u => u.role === 'waiter').map((w) => {
                    const sales = salesHistory.filter(s => s.waiterId === w.id).reduce((sum, s) => sum + s.total, 0);
                    const debtsList = waiterDebts[w.id] || [];
                    const totalDebt = debtsList.reduce((sum, d) => sum + d.qty * d.price, 0);
                    return (
                      <tr key={w.id} className="hover:bg-slate-50/50">
                        <td className="p-3 font-mono font-bold text-slate-500">{w.id}</td>
                        <td className="p-3 font-bold text-slate-800">{w.name}</td>
                        <td className="p-3 font-semibold text-emerald-600">{formatCurrency(sales)}</td>
                        <td className="p-3 font-black text-red-500">{formatCurrency(totalDebt)}</td>
                        <td className="p-3 text-center">
                          <button
                            onClick={() => {
                              if (confirm(`የአስተናጋጅ ${w.name} ሂሳብ ወይም እዳ መረከብዎን ያረጋግጣሉ?`)) {
                                onClearWaiterDebt(w.id);
                                alert('እዳው ሙሉ በሙሉ ተጠርጓል!');
                              }
                            }}
                            className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-3 py-1.5 rounded-xl shadow text-[10px] cursor-pointer transition-all"
                          >
                            ሂሳብ ተረክቤያለሁ
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* BARMAN HANDOVER MANAGEMENT */}
      <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
        <div
          onClick={() => toggleSection('barmanHandover')}
          className="p-4 md:p-5 font-bold text-slate-800 flex justify-between items-center bg-slate-50 border-b border-slate-100 cursor-pointer select-none"
        >
          <span className="flex items-center gap-2"><Beer className="text-amber-500" /> 🍺 ለባርማን ዕቃ ማስረከቢያ እና ቁጥጥር (Handover to Barman)</span>
          <span className="text-[11px] bg-slate-200 px-3 py-1 rounded-full font-bold">መንካት</span>
        </div>

        {openSection.barmanHandover && (
          <div className="p-5 space-y-6">
            {/* Handover Form */}
            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 space-y-4">
              <h4 className="text-xs font-black text-slate-700">📋 ዕቃ ማስረከቢያ ፎርም</h4>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 mb-1 uppercase">ተረካቢ ባርማን</label>
                  <select
                    value={handoverBarmanId}
                    onChange={(e) => setHandoverBarmanId(e.target.value)}
                    className="w-full border p-2.5 rounded-xl text-xs font-bold bg-white focus:outline-none"
                  >
                    <option value="">-- ባርማን ይምረጡ --</option>
                    {users.filter(u => u.role === 'barman').map(b => (
                      <option key={b.id} value={b.id}>{b.name} ({b.id})</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-500 mb-1 uppercase">የዕቃ አይነት (ከስቶር)</label>
                  <select
                    value={handoverCode}
                    onChange={(e) => setHandoverCode(e.target.value)}
                    className="w-full border p-2.5 rounded-xl text-xs font-bold bg-white focus:outline-none"
                  >
                    <option value="">-- ዕቃ ይምረጡ --</option>
                    {store.map(i => (
                      <option key={i.code} value={i.code}>{i.name} (ስቶር ቀሪ: {i.stock})</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-500 mb-1 uppercase">የሚረከበው ብዛት</label>
                  <input
                    type="number"
                    min="1"
                    value={handoverQty}
                    onChange={(e) => setHandoverQty(e.target.value)}
                    className="w-full border p-2.5 rounded-xl text-xs font-bold bg-white focus:outline-none text-center"
                  />
                </div>
              </div>

              <button
                onClick={handleHandoverSubmit}
                className="bg-amber-500 hover:bg-amber-600 text-white font-bold px-6 py-2.5 rounded-xl text-xs shadow cursor-pointer transition-all"
              >
                እቃውን አስረክብ
              </button>
            </div>

            {/* Barmen Current Stock Inventory List */}
            <div className="space-y-3">
              <h4 className="text-xs font-black text-slate-700 flex items-center gap-1">
                📦 የባርማኖች እጅ ላይ የሚገኝ ቀሪ ዕቃና ክምችት ዝርዝር
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {users.filter(u => u.role === 'barman').map(barman => {
                  const bStock = barmanReceivedItems[barman.id] || {};
                  const itemsList = Object.entries(bStock).filter(([_, item]) => item.qty > 0);
                  const totalValue = itemsList.reduce((sum, [_, item]) => sum + item.qty * item.price, 0);

                  return (
                    <div key={barman.id} className="bg-white border rounded-2xl p-4 shadow-sm space-y-3">
                      <div className="flex justify-between items-center border-b pb-2">
                        <span className="font-extrabold text-xs text-slate-800">🧑‍🍳 {barman.name} ({barman.id})</span>
                        <span className="text-[10px] font-black text-emerald-600 bg-emerald-50 px-2.5 py-0.5 rounded-full">
                          የክምችት ዋጋ፦ {formatCurrency(totalValue)}
                        </span>
                      </div>

                      <div className="overflow-x-auto max-h-48 overflow-y-auto">
                        <table className="min-w-full text-[10px] text-left">
                          <thead className="bg-slate-50 text-slate-600 font-extrabold">
                            <tr>
                              <th className="p-2">የዕቃ ስም</th>
                              <th className="p-2 text-center">ቀሪ ብዛት</th>
                              <th className="p-2 text-right">ዋጋ</th>
                              <th className="p-2 text-right">ድምር</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y font-semibold text-slate-700">
                            {itemsList.map(([code, item]) => (
                              <tr key={code}>
                                <td className="p-2 font-bold">{item.name}</td>
                                <td className="p-2 text-center text-slate-900 font-black">{item.qty}</td>
                                <td className="p-2 text-right">{formatCurrency(item.price)}</td>
                                <td className="p-2 text-right text-emerald-600">{formatCurrency(item.qty * item.price)}</td>
                              </tr>
                            ))}
                            {itemsList.length === 0 && (
                              <tr>
                                <td colSpan={4} className="p-4 text-center text-slate-400 italic">
                                  ይህ ባርማን በእጁ ላይ ምንም ዕቃ የለም።
                                </td>
                              </tr>
                            )}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* BARMAN DEBT SETTLEMENT */}
      <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
        <div
          onClick={() => toggleSection('barmanSettlement')}
          className="p-4 md:p-5 font-bold text-slate-800 flex justify-between items-center bg-slate-50 border-b border-slate-100 cursor-pointer select-none"
        >
          <span className="flex items-center gap-2"><DollarSign className="text-indigo-600" /> 📊 የባርማን እዳዎች እና ሂሳብ ማጽጃ ሰሌዳ (Barman Debts & Settlement)</span>
          <span className="text-[11px] bg-slate-200 px-3 py-1 rounded-full font-bold">መንካት</span>
        </div>

        {openSection.barmanSettlement && (
          <div className="p-4 space-y-4">
            <div className="overflow-x-auto rounded-2xl border border-slate-100">
              <table className="min-w-full bg-white text-xs text-left">
                <thead className="bg-slate-50 border-b border-slate-100 font-extrabold text-slate-700">
                  <tr>
                    <th className="p-3">የባርማን መለያ</th>
                    <th className="p-3">ስም</th>
                    <th className="p-3 text-red-500">በእጅ ላይ የሚገኝ እቃ እዳ (ዋጋ)</th>
                    <th className="p-3 text-center">ሂሳብ ተረክብ / እዳ አጽዳ</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium">
                  {users.filter(u => u.role === 'barman').map((b) => {
                    const bStock = barmanReceivedItems[b.id] || {};
                    const totalDebtValue = Object.values(bStock).reduce((sum, item) => sum + item.qty * item.price, 0);

                    return (
                      <tr key={b.id} className="hover:bg-slate-50/50">
                        <td className="p-3 font-mono font-bold text-slate-500">{b.id}</td>
                        <td className="p-3 font-bold text-slate-800">{b.name}</td>
                        <td className="p-3 font-black text-red-500">{formatCurrency(totalDebtValue)}</td>
                        <td className="p-3 text-center">
                          <button
                            onClick={() => {
                              if (confirm(`የባርማን ${b.name} ቀሪ ዕቃዎች ሂሳብ/እዳ መረከብዎን እና መዝገቡን ማጽዳትዎን ያረጋግጣሉ?`)) {
                                onClearBarmanDebt(b.id);
                                alert('የባርማኑ እዳ ሙሉ በሙሉ ተጠርጓል!');
                              }
                            }}
                            className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold px-3 py-1.5 rounded-xl shadow text-[10px] cursor-pointer transition-all"
                          >
                            እዳ/ሂሳብ ተረክቤያለሁ
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* CARAMBULA GAME CONTROLLER */}
      <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
        <div
          onClick={() => toggleSection('gamesController')}
          className="p-4 md:p-5 font-bold text-slate-800 flex justify-between items-center bg-slate-50 border-b border-slate-100 cursor-pointer select-none"
        >
          <span className="flex items-center gap-2"><Dices className="text-purple-600" /> 🎮 የካራንቡላ አጫዋች መቆጣጠሪያ እና የገቢ ሪፖርት (Carambula Game Control)</span>
          <span className="text-[11px] bg-slate-200 px-3 py-1 rounded-full font-bold">መንካት</span>
        </div>

        {openSection.gamesController && (
          <div className="p-5 space-y-6">
            {/* Start New Game Form */}
            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 space-y-4">
              <h4 className="text-xs font-black text-slate-700">🎯 አዲስ ጨዋታ ማስጀመሪያ</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 mb-1 uppercase">የአጫዋች ስም</label>
                  <input
                    type="text"
                    placeholder="የደንበኛውን ወይም የአጫዋቹን ስም ያስገቡ"
                    value={gamePlayerName}
                    onChange={(e) => setGamePlayerName(e.target.value)}
                    className="w-full border border-slate-200 p-2.5 rounded-xl text-xs font-semibold focus:outline-none focus:border-purple-500 bg-white"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-500 mb-1 uppercase">ቦታ/ጠረጴዛ (ካራንቡላ ቁጥር)</label>
                  <select
                    value={gameSpot}
                    onChange={(e) => setGameSpot(e.target.value)}
                    className="w-full border p-2.5 rounded-xl text-xs font-bold bg-white focus:outline-none focus:border-purple-500"
                  >
                    {[1, 2, 3, 4, 5].map(num => (
                      <option key={num} value={num}>ካራንቡላ {num}</option>
                    ))}
                  </select>
                </div>
              </div>

              <button
                onClick={handleStartGameSubmit}
                className="bg-purple-600 hover:bg-purple-700 text-white font-bold px-6 py-2.5 rounded-xl text-xs shadow cursor-pointer transition-all"
              >
                ጨዋታ ጀምር
              </button>
            </div>

            {/* Active Games Grid */}
            <div className="space-y-3">
              <h4 className="text-xs font-black text-slate-700">⚡ አሁን በመጫወት ላይ ያሉ ንቁ ጨዋታዎች</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                {games.filter(g => g.status === 'active').map(game => {
                  const elapsedMs = new Date().getTime() - new Date(game.startTime).getTime();
                  const elapsedMinutes = Math.max(1, Math.floor(elapsedMs / 60000));
                  const cost = elapsedMinutes * 1.70;

                  return (
                    <div key={game.id} className="bg-white border-2 border-purple-100 rounded-2xl p-4 shadow-sm space-y-3 relative overflow-hidden">
                      <div className="absolute top-0 right-0 bg-purple-500 text-white text-[9px] font-bold px-3 py-1 rounded-bl-xl animate-pulse">
                        በመጫወት ላይ
                      </div>
                      
                      <div className="space-y-1">
                        <span className="text-[10px] text-purple-600 font-extrabold bg-purple-50 px-2 py-0.5 rounded-full">
                          ካራንቡላ {game.location}
                        </span>
                        <h5 className="font-bold text-slate-800 text-sm pt-1">{game.customerName}</h5>
                        <p className="text-[10px] text-slate-400 font-medium">የተጀመረበት ሰዓት፦ {new Date(game.startTime).toLocaleTimeString()}</p>
                      </div>

                      <div className="grid grid-cols-2 gap-2 border-t pt-2 text-center">
                        <div>
                          <span className="block text-[9px] font-bold text-slate-400 uppercase">ቆይታ</span>
                          <span className="text-sm font-black text-slate-800">{elapsedMinutes} ደቂቃ</span>
                        </div>
                        <div>
                          <span className="block text-[9px] font-bold text-slate-400 uppercase">የአሁን ሂሳብ</span>
                          <span className="text-sm font-black text-emerald-600">{formatCurrency(cost)}</span>
                        </div>
                      </div>

                      <button
                        onClick={() => {
                          if (confirm(`የጨዋታ ቁጥር ${game.id} (አጫዋች፡ ${game.customerName}) ጨዋታ ማቆም እና ሂሳብ መዝጋት ይፈልጋሉ?`)) {
                            onEndGame(game.id);
                            alert('ጨዋታ ተዘግቷል!');
                          }
                        }}
                        className="w-full bg-red-500 hover:bg-red-600 text-white font-bold py-2 rounded-xl text-xs cursor-pointer transition-all shadow"
                      >
                        ጨዋታውን ዝጋ (ማቆሚያ)
                      </button>
                    </div>
                  );
                })}
                {games.filter(g => g.status === 'active').length === 0 && (
                  <div className="col-span-full py-8 text-center text-slate-400 italic font-bold text-xs bg-slate-50 border border-dashed rounded-2xl">
                    በአሁኑ ሰዓት ምንም ንቁ ጨዋታ የለም።
                  </div>
                )}
              </div>
            </div>

            {/* Closed Games History Table & Export */}
            <div className="space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-50 p-3.5 rounded-2xl border">
                <h4 className="text-xs font-black text-slate-700">📂 ያለፉ የጨዋታ ታሪኮች እና ሪፖርት</h4>
                <button
                  onClick={() => {
                    const closedGames = games.filter(g => g.status === 'closed');
                    const formatted = closedGames.map((g, i) => ({
                      'ተ.ቁ': i + 1,
                      'አጫዋች ስም': g.customerName,
                      'ካራንቡላ ቁጥር': g.location,
                      'የተጀመረበት': new Date(g.startTime).toLocaleString(),
                      'የተጠናቀቀበት': g.endTime ? new Date(g.endTime).toLocaleString() : 'N/A',
                      'የፈጀው ደቂቃ': g.minutes,
                      'ዋጋ (ብር)': g.cost
                    }));
                    downloadExcel(formatted, 'Carambula_Games_Report');
                    alert('የካራንቡላ ጨዋታዎች ሪፖርት በተሳካ ሁኔታ ወርዷል!');
                  }}
                  className="bg-slate-800 hover:bg-slate-900 text-white px-4 py-2.5 rounded-xl text-xs font-bold shadow flex items-center justify-center gap-1.5 cursor-pointer self-start sm:self-auto"
                >
                  <Download size={14} /> የካራንቡላ Excel ሪፖርት አውርድ
                </button>
              </div>

              <div className="overflow-x-auto rounded-2xl border border-slate-100">
                <table className="min-w-full bg-white text-xs text-left">
                  <thead className="bg-slate-50 border-b border-slate-100 font-extrabold text-slate-700">
                    <tr>
                      <th className="p-3 text-center">ተ.ቁ</th>
                      <th className="p-3">አጫዋች ስም</th>
                      <th className="p-3 text-center">ካራንቡላ ቁጥር</th>
                      <th className="p-3 text-center">የፈጀው ጊዜ</th>
                      <th className="p-3 text-right">የጨዋታ ዋጋ</th>
                      <th className="p-3">ቀን እና ሰዓት</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                    {games.filter(g => g.status === 'closed').reverse().map((g, i) => (
                      <tr key={g.id} className="hover:bg-slate-50/50">
                        <td className="p-3 text-center font-mono text-slate-500">{i + 1}</td>
                        <td className="p-3 font-bold text-slate-800">{g.customerName}</td>
                        <td className="p-3 text-center font-bold text-purple-600">ካራንቡላ {g.location}</td>
                        <td className="p-3 text-center font-extrabold">{g.minutes} ደቂቃ</td>
                        <td className="p-3 text-right font-black text-emerald-600">{formatCurrency(g.cost)}</td>
                        <td className="p-3 text-slate-400 font-medium">{new Date(g.startTime).toLocaleDateString()} {new Date(g.startTime).toLocaleTimeString()}</td>
                      </tr>
                    ))}
                    {games.filter(g => g.status === 'closed').length === 0 && (
                      <tr>
                        <td colSpan={6} className="p-6 text-center text-slate-400 italic font-bold">
                          ምንም ያለፉ የጨዋታ ታሪኮች አልተመዘገቡም።
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* COMPLAINTS & FEEDBACK */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Complaints Section */}
        <div className="bg-red-50/50 p-5 rounded-3xl border border-red-200 shadow-sm space-y-3">
          <h3 className="font-extrabold text-red-800 text-sm flex items-center gap-1.5">
            <AlertTriangle size={18} /> የአስተናጋጆች ዕቃ ቅሬታ (Complaints)
          </h3>
          <div className="space-y-2 max-h-60 overflow-y-auto">
            {complaints.map((c) => (
              <div key={c.firebaseKey} className="bg-white p-3 rounded-2xl border border-red-100 flex items-center justify-between gap-2 shadow-sm">
                <div className="text-xs">
                  <span className="font-bold text-slate-800">{c.waiterName}</span>፦
                  <span className="font-semibold text-red-600 ml-1">{c.itemName} (ብዛት {c.qty})</span> ቀሪ ወይም ትርፍ ዕቃ ችግር አለበት ብሏል።
                </div>
                <button
                  onClick={() => c.firebaseKey && onDismissComplaint(c.firebaseKey)}
                  className="bg-red-600 hover:bg-red-700 text-white px-3 py-1.5 rounded-xl font-bold text-[10px] shadow cursor-pointer shrink-0"
                >
                  አጽዳ
                </button>
              </div>
            ))}
            {complaints.length === 0 && (
              <p className="text-xs text-red-400 italic text-center py-4 font-bold">ምንም የዕቃ ቅሬታ አልቀረበም</p>
            )}
          </div>
        </div>

        {/* Feedback Section */}
        <div className="bg-blue-50/50 p-5 rounded-3xl border border-blue-200 shadow-sm space-y-3">
          <h3 className="font-extrabold text-blue-800 text-sm flex items-center gap-1.5">
            <MessageSquare size={18} /> የደንበኞች አስተያየትና ቅሬታዎች
          </h3>
          <div className="space-y-2 max-h-60 overflow-y-auto">
            {feedbacks.map((f, i) => (
              <div key={i} className="bg-white p-3 rounded-2xl border border-blue-100 shadow-sm space-y-1">
                <div className="flex justify-between items-center">
                  <span className="text-[10px] font-black text-blue-700 bg-blue-100/50 px-2.5 py-0.5 rounded-full">
                    ጠረጴዛ {f.tableId}
                  </span>
                  <span className="text-[10px] text-slate-400 font-medium">{f.time}</span>
                </div>
                <p className="text-xs font-bold text-slate-700">{f.message}</p>
              </div>
            ))}
            {feedbacks.length === 0 && (
              <p className="text-xs text-blue-400 italic text-center py-4 font-bold">ምንም አስተያየት አልደረሰም</p>
            )}
          </div>
        </div>
      </div>

      {/* PRICE MODAL */}
      {showPriceModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white p-6 rounded-3xl max-w-sm w-full space-y-4 shadow-2xl border">
            <h3 className="text-base font-black text-slate-800">✏️ የዕቃ ዋጋ ማሻሻያ</h3>
            <div>
              <label className="block text-[10px] font-bold text-slate-500 mb-1">ዕቃ ይምረጡ</label>
              <select
                value={editCode}
                onChange={(e) => setEditCode(e.target.value)}
                className="w-full border p-2.5 rounded-xl text-xs font-bold bg-white"
              >
                <option value="">-- ይምረጡ --</option>
                {store.map(i => (
                  <option key={i.code} value={i.code}>{i.name} ({formatCurrency(i.price)})</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-500 mb-1">አዲስ መሸጫ ዋጋ</label>
              <input
                type="number"
                placeholder="አዲሱን መሸጫ ዋጋ ያስገቡ"
                value={editPrice}
                onChange={(e) => setEditPrice(e.target.value)}
                className="w-full border p-2.5 rounded-xl text-xs font-semibold"
              />
            </div>
            <div className="flex gap-2">
              <button
                onClick={handlePriceUpdate}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2.5 rounded-xl font-bold text-xs cursor-pointer shadow"
              >
                አድስ / ቀይር
              </button>
              <button
                onClick={() => setShowPriceModal(false)}
                className="w-full bg-slate-100 hover:bg-slate-200 text-slate-700 py-2.5 rounded-xl font-bold text-xs cursor-pointer"
              >
                ዝጋ
              </button>
            </div>
          </div>
        </div>
      )}

      {/* QR MODAL */}
      {showQrModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white p-6 rounded-3xl max-w-xs w-full space-y-4 shadow-2xl border text-center">
            <h3 className="text-base font-black text-slate-800">{qrLabel} ዲጂታል ማዘዣ QR</h3>
            <div className="bg-slate-50 p-4 rounded-2xl flex justify-center border">
              <img src={qrUrl} alt="Table QR" className="max-w-full" />
            </div>
            <p className="text-[10px] text-slate-500 font-bold">
              ይህንን QR ኮድ ጠረጴዛው ላይ በመለጠፍ ደንበኞች ስማርት ስልካቸውን በመጠቀም ማዘዝ እንዲችሉ ማድረግ ይችላሉ።
            </p>
            <button
              onClick={() => setShowQrModal(false)}
              className="w-full bg-slate-800 hover:bg-slate-900 text-white py-2.5 rounded-xl font-bold text-xs cursor-pointer"
            >
              ዝጋ
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
