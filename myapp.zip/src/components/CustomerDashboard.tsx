import React, { useState, useEffect } from 'react';
import { StoreItem, TableOrder, User } from '../types';
import { Utensils, Star, MessageSquare, ShoppingCart, Check, Heart } from 'lucide-react';
import { formatCurrency } from '../utils';

interface CustomerDashboardProps {
  tableNum: number;
  store: StoreItem[];
  tableOrders: { [tableId: string]: TableOrder };
  users: User[];
  onAddCustomerOrder: (tableId: number, itemCode: string, qty: number, customerName: string) => void;
  onSubmitRating: (waiterId: string, rating: number, customerName: string, tableId: number) => void;
  onSubmitFeedback: (tableId: number, msg: string) => void;
}

export default function CustomerDashboard({
  tableNum,
  store,
  tableOrders,
  users,
  onAddCustomerOrder,
  onSubmitRating,
  onSubmitFeedback,
}: CustomerDashboardProps) {
  const [customerName, setCustomerName] = useState(() => {
    return localStorage.getItem('hotelCustomerName') || '';
  });
  const [nameInput, setNameInput] = useState('');
  const [category, setCategory] = useState('ምግብ');
  const [itemCode, setItemCode] = useState('');
  const [orderQty, setOrderQty] = useState('1');

  // Rating forms
  const [selectedWaiter, setSelectedWaiter] = useState('');
  const [selectedStars, setSelectedStars] = useState(0);
  const [ratingMessage, setRatingMessage] = useState('');

  // Suggestions
  const [feedbackMsg, setFeedbackMsg] = useState('');

  // Auto-select the first item in the selected category on category change
  const filteredStoreItems = store.filter(i => i.category === category && i.stock > 0);

  useEffect(() => {
    if (filteredStoreItems.length > 0) {
      setItemCode(filteredStoreItems[0].code);
    } else {
      setItemCode('');
    }
  }, [category, store]);

  // Set default rated waiter
  useEffect(() => {
    const waiters = users.filter(u => u.role === 'waiter');
    if (waiters.length > 0 && !selectedWaiter) {
      setSelectedWaiter(waiters[0].id);
    }
  }, [users]);

  const handleSaveName = () => {
    if (!nameInput.trim()) return alert('እባክዎ ስም ያስገቡ!');
    setCustomerName(nameInput.trim());
    localStorage.setItem('hotelCustomerName', nameInput.trim());
    setNameInput('');
    alert(`ስምዎ ተቀምጧል! እንኳን ደህና መጡ፣ ${nameInput.trim()}!`);
  };

  const handlePlaceOrder = () => {
    if (!customerName) return alert('እባክዎ መጀመሪያ ስምዎን ያስገቡ!');
    if (!itemCode || !orderQty) return alert('እባክዎ ምግብ/መጠጥ እና ብዛት ይምረጡ!');
    const qty = parseInt(orderQty);
    if (isNaN(qty) || qty <= 0) return alert('ትክክለኛ ቁጥር ያስገቡ');

    const sItem = store.find(i => i.code === itemCode);
    if (!sItem) return alert('ዕቃው አልተገኘም');
    if (sItem.stock < qty) return alert(`ይቅርታ፣ በቂ ቀሪ ክምችት የለም! ቀሪ: ${sItem.stock}`);

    onAddCustomerOrder(tableNum, itemCode, qty, customerName);
    setOrderQty('1');
    alert('🚀 ትዕዛዝዎ በተሳካ ሁኔታ ተልኳል!');
  };

  const handleSendFeedback = () => {
    if (!feedbackMsg.trim()) return alert('እባክዎ አስተያየትዎን ይጻፉ!');
    onSubmitFeedback(tableNum, feedbackMsg.trim());
    setFeedbackMsg('');
    alert('አስተያየትዎ ለባለቤቱ ተልኳል! እናመሰግናለን!');
  };

  const handleSendRating = () => {
    if (!customerName) return alert('እባክዎ መጀመሪያ ስምዎን ያስገቡ!');
    if (!selectedWaiter) return alert('እባክዎ አስተናጋጅ ይምረጡ!');
    if (selectedStars < 1 || selectedStars > 5) return alert('እባክዎ ከ1-5 ኮኮቦች ይምረጡ!');

    onSubmitRating(selectedWaiter, selectedStars, customerName, tableNum);
    const wName = users.find(u => u.id === selectedWaiter)?.name || 'አስተናጋጁ';
    setRatingMessage(`✅ ለአስተናጋጁ ${wName} ${selectedStars} ኮኮቦች ምዘና ተልኳል!`);
    setSelectedStars(0);
  };

  // Order summaries
  const tableOrder = tableOrders[tableNum.toString()];
  const customerItems = (tableOrder && tableOrder.status === 'open')
    ? tableOrder.items.filter(i => i.source === 'customer')
    : [];
  const waiterItems = (tableOrder && tableOrder.status === 'open')
    ? tableOrder.items.filter(i => i.source === 'waiter')
    : [];

  const customerTotal = customerItems.reduce((s, i) => s + i.price * i.qty, 0);
  const waiterTotal = waiterItems.reduce((s, i) => s + i.price * i.qty, 0);
  const grandTotal = customerTotal + waiterTotal;

  return (
    <div className="space-y-6">
      {/* HEADER CARD */}
      <div className="text-center p-5 bg-gradient-to-r from-amber-500 via-orange-500 to-yellow-500 rounded-3xl border-2 border-orange-300 text-white shadow-lg">
        <Heart className="inline-block text-white mb-2 animate-bounce" size={24} fill="currentColor" />
        <h3 className="text-xl font-black font-display tracking-tight">
          🌟 እንኳን ወደ ዲጂታል ማዘዣ ገጻችን በደህና መጡ!!!
        </h3>
        <p className="text-xs font-bold mt-1 text-orange-50">
          ጠረጴዛ {tableNum} — በዲጂታል አገልግሎታችን እንደሚደሰቱ ሙሉ እምነት አለን!!!
        </p>
      </div>

      {/* BILL BREAKDOWNS (TWO COLUMNS ON DESKTOP) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Customer placed orders */}
        <div className="bg-white p-5 rounded-3xl shadow-md border-t-4 border-orange-500 space-y-3">
          <h3 className="font-extrabold text-slate-800 text-xs flex items-center gap-1.5 border-b pb-2 text-orange-700 uppercase">
            <ShoppingCart size={16} /> 🧾 በእርስዎ ስልክ የታዘዙ ምግቦች
          </h3>
          <div className="space-y-2 max-h-60 overflow-y-auto">
            {customerItems.map((item, idx) => (
              <div key={idx} className="flex justify-between items-center text-xs p-2 bg-slate-50 border rounded-xl">
                <div>
                  <p className="font-bold text-slate-800">{item.name}</p>
                  <p className="text-[10px] text-slate-400 font-bold">{formatCurrency(item.price)} x {item.qty}</p>
                </div>
                <span className="font-black text-slate-700">{formatCurrency(item.price * item.qty)}</span>
              </div>
            ))}
            {customerItems.length === 0 && (
              <p className="text-xs text-slate-400 italic text-center py-6 font-semibold">እስካሁን ምንም ነገር አላዘዙም</p>
            )}
          </div>
          <div className="bg-orange-50 p-3 rounded-2xl border border-orange-100 text-center">
            <span className="block text-[10px] text-slate-400 font-bold uppercase">የእርስዎ ትዕዛዞች ጠቅላላ</span>
            <span className="text-lg font-black text-orange-600 block">{formatCurrency(customerTotal)}</span>
          </div>
        </div>

        {/* Waiter added/served orders */}
        <div className="bg-white p-5 rounded-3xl shadow-md border-t-4 border-emerald-500 space-y-3">
          <h3 className="font-extrabold text-slate-800 text-xs flex items-center gap-1.5 border-b pb-2 text-emerald-700 uppercase">
            <Check size={16} /> 🍽️ በአስተናጋጅ የቀረቡልዎት ምግቦች
          </h3>
          <div className="space-y-2 max-h-60 overflow-y-auto">
            {waiterItems.map((item, idx) => (
              <div key={idx} className="flex justify-between items-center text-xs p-2 bg-slate-50 border rounded-xl">
                <div>
                  <p className="font-bold text-slate-800">{item.name}</p>
                  <p className="text-[10px] text-slate-400 font-bold">{formatCurrency(item.price)} x {item.qty}</p>
                </div>
                <span className="font-black text-slate-700">{formatCurrency(item.price * item.qty)}</span>
              </div>
            ))}
            {waiterItems.length === 0 && (
              <p className="text-xs text-slate-400 italic text-center py-6 font-semibold">በአስተናጋጅ እስካሁን ምንም አልቀረበም</p>
            )}
          </div>
          <div className="bg-emerald-50 p-3 rounded-2xl border border-emerald-100 text-center">
            <span className="block text-[10px] text-slate-400 font-bold uppercase">በአስተናጋጅ የቀረቡ ጠቅላላ</span>
            <span className="text-lg font-black text-emerald-600 block">{formatCurrency(waiterTotal)}</span>
          </div>
        </div>
      </div>

      {/* GRAND TOTAL INVOICE */}
      <div className="bg-amber-50 p-5 rounded-3xl border border-amber-200 text-center shadow-inner">
        <span className="text-xs font-bold text-slate-600 uppercase tracking-wider block">🧾 በአጠቃላይ የሚከፈል ሂሳብ</span>
        <span className="text-3xl font-black text-amber-600 block mt-1">{formatCurrency(grandTotal)}</span>
      </div>

      {/* CUSTOMER CUSTOM NAME REGISTRATION */}
      <div className="bg-emerald-50/50 p-5 rounded-3xl border border-emerald-100 shadow-sm space-y-3">
        <label className="block text-xs font-bold text-emerald-800 uppercase tracking-wide">👤 እባክዎ ስምዎን ያስገቡ (ትዕዛዝ ከመላክዎ በፊት)</label>
        <div className="flex gap-2">
          <input
            type="text"
            placeholder="የእርስዎ ስም ለምሳሌ፡ ሚካኤል"
            value={nameInput}
            onChange={(e) => setNameInput(e.target.value)}
            className="w-full border border-slate-200 p-2.5 rounded-xl text-xs font-bold bg-white focus:outline-none focus:border-emerald-500"
          />
          <button
            onClick={handleSaveName}
            className="bg-emerald-600 hover:bg-emerald-700 text-white px-5 py-2.5 rounded-xl text-xs font-bold shadow shrink-0 cursor-pointer"
          >
            አስቀምጥ
          </button>
        </div>
        {customerName && (
          <p className="text-xs font-bold text-emerald-800 bg-emerald-50 p-2.5 rounded-xl border border-emerald-100 inline-flex items-center gap-1.5">
            <Check size={14} /> ተጠቃሚ ስም፦ {customerName}
          </p>
        )}
      </div>

      {/* PLACE NEW ORDER */}
      <div className="bg-white p-5 rounded-3xl border border-slate-100 shadow-md space-y-3">
        <h3 className="font-extrabold text-sm text-slate-800">🛒 ምግብና መጠጥ ማዘዣ ሰሌዳ</h3>
        
        <div className="space-y-3 bg-slate-50 p-4 rounded-2xl border">
          <div>
            <label className="block text-[10px] font-bold text-slate-500 mb-1 uppercase">ምድብ ይምረጡ</label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full border p-2.5 rounded-xl text-xs font-bold bg-white focus:outline-none"
            >
              <option value="ምግብ">ምግብ (Food)</option>
              <option value="መጠጥ">መጠጥ (Drinks)</option>
              <option value="ደረቅ መጠጦች">ደረቅ መጠጦች (Soft Drinks)</option>
            </select>
          </div>

          <div className="grid grid-cols-3 gap-2">
            <div className="col-span-2">
              <label className="block text-[10px] font-bold text-slate-500 mb-1 uppercase">ምግብ/መጠጥ</label>
              <select
                value={itemCode}
                onChange={(e) => setItemCode(e.target.value)}
                className="w-full border p-2.5 rounded-xl text-xs font-bold bg-white focus:outline-none"
              >
                {filteredStoreItems.map(item => (
                  <option key={item.code} value={item.code}>{item.name} ({formatCurrency(item.price)})</option>
                ))}
                {filteredStoreItems.length === 0 && <option value="">ምንም ዕቃ የለም</option>}
              </select>
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-500 mb-1 uppercase">ብዛት</label>
              <input
                type="number"
                min="1"
                value={orderQty}
                onChange={(e) => setOrderQty(e.target.value)}
                className="w-full border p-2.5 rounded-xl text-xs font-black bg-white text-center focus:outline-none"
              />
            </div>
          </div>
        </div>

        <button
          onClick={handlePlaceOrder}
          className="w-full bg-orange-500 hover:bg-orange-600 text-white py-3.5 rounded-2xl font-black text-sm shadow-md shadow-orange-500/10 cursor-pointer active:scale-98 transition-all"
        >
          🚀 ትዕዛዝ ላክ (Place Order)
        </button>
      </div>

      {/* WAITER RATING/STARS FORM */}
      <div className="bg-white p-5 rounded-3xl border border-slate-100 shadow-md space-y-4">
        <h3 className="font-extrabold text-sm text-slate-800">⭐ በአገልግሎት አሰጣጥ ላይ አስተናጋጅዎን ደረጃ ይስጡ</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 bg-slate-50 p-4 rounded-2xl border">
          <div>
            <label className="block text-[10px] font-bold text-slate-500 mb-1 uppercase">አስተናጋጅ ይምረጡ</label>
            <select
              value={selectedWaiter}
              onChange={(e) => setSelectedWaiter(e.target.value)}
              className="w-full border p-2.5 rounded-xl text-xs font-bold bg-white focus:outline-none"
            >
              {users.filter(u => u.role === 'waiter').map(w => (
                <option key={w.id} value={w.id}>{w.name}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[10px] font-bold text-slate-500 mb-1 uppercase">ደረጃ (1-5 ኮኮቦች)</label>
            <div className="flex items-center gap-1.5 mt-1.5">
              {[1, 2, 3, 4, 5].map((star) => (
                <span
                  key={star}
                  onClick={() => setSelectedStars(star)}
                  className={`text-2xl cursor-pointer select-none transition-all duration-100 ${
                    star <= selectedStars ? 'text-amber-500 scale-110' : 'text-slate-300'
                  }`}
                >
                  ★
                </span>
              ))}
            </div>
          </div>

          <div className="flex items-end">
            <button
              onClick={handleSendRating}
              className="w-full bg-purple-600 hover:bg-purple-700 text-white font-bold py-2.5 rounded-xl text-xs shadow cursor-pointer"
            >
              ኮኮቦች ላክ
            </button>
          </div>
        </div>

        {ratingMessage && (
          <p className="text-xs font-bold text-purple-700 bg-purple-50 p-2.5 rounded-xl border border-purple-100">
            {ratingMessage}
          </p>
        )}
      </div>

      {/* DIRECT FEEDBACK / SUGGESTIONS TO THE OWNER */}
      <div className="bg-blue-50/50 p-5 rounded-3xl border border-blue-200 shadow-sm space-y-3">
        <h3 className="font-extrabold text-xs text-blue-800 uppercase tracking-wider flex items-center gap-1">
          <MessageSquare size={14} /> 💬 ለሆቴሉ ባለቤት ቀጥታ ቅሬታ/አስተያየት መላኪያ
        </h3>
        <div className="flex gap-2">
          <input
            type="text"
            placeholder="አስተያየትዎን ወይም ያጋጠመዎትን ችግር እዚህ ይጻፉ..."
            value={feedbackMsg}
            onChange={(e) => setFeedbackMsg(e.target.value)}
            className="w-full border border-slate-200 p-2.5 rounded-xl text-xs font-semibold bg-white focus:outline-none focus:border-blue-500"
          />
          <button
            onClick={handleSendFeedback}
            className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2.5 rounded-xl text-xs font-bold shadow shrink-0 cursor-pointer"
          >
            ላክ
          </button>
        </div>
      </div>
    </div>
  );
}
