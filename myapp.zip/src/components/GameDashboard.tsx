import React, { useState } from 'react';
import { Game } from '../types';
import { Dices, Plus, Clipboard, Scale, Play, CheckCircle, Download } from 'lucide-react';
import { formatCurrency, downloadExcel } from '../utils';

interface GameDashboardProps {
  games: Game[];
  onStartGame: (customerName: string, location: number) => void;
  onEndGame: (gameId: number) => void;
}

export default function GameDashboard({
  games,
  onStartGame,
  onEndGame,
}: GameDashboardProps) {
  const [customerNameInput, setCustomerNameInput] = useState('');
  const [selectedLocation, setSelectedLocation] = useState('1');
  const [selectedEndId, setSelectedEndId] = useState('');
  const [gameReportFilter, setGameReportFilter] = useState<'all' | 'daily' | 'weekly' | 'monthly' | 'yearly'>('all');

  const LOCATIONS = [1, 2, 3, 4, 5];
  const GAME_RATE = 1.70; // 1.70 Birr per minute

  // Calculate stats
  const activeGames = games.filter(g => g.status === 'active');
  const closedGames = games.filter(g => g.status === 'closed');
  const openSpots = LOCATIONS.filter(loc => !activeGames.find(g => g.location === loc)).length;
  const occupiedSpots = LOCATIONS.length - openSpots;

  const todayStr = new Date().toDateString();
  const dailyGameRevenue = closedGames
    .filter(g => g.endTime && new Date(g.endTime).toDateString() === todayStr)
    .reduce((sum, g) => sum + (g.cost || 0), 0);

  // Handle Game Start
  const handleStartGame = () => {
    if (!customerNameInput.trim()) return alert('እባክዎ የደንበኛ ስም ያስገቡ!');
    const loc = parseInt(selectedLocation);
    if (activeGames.find(g => g.location === loc)) {
      return alert(`ቦታ ${loc} በአሁኑ ሰዓት ተይዟል!`);
    }

    onStartGame(customerNameInput.trim(), loc);
    setCustomerNameInput('');
    alert(`🎮 ጨዋታ በቦታ ${loc} ተጀምሯል!`);
  };

  // Handle Game End
  const handleEndGame = () => {
    if (!selectedEndId) return alert('እባክዎ የሚዘጋ ጨዋታ ይምረጡ!');
    onEndGame(parseInt(selectedEndId));
    setSelectedEndId('');
  };

  // Filter game report for display
  const getFilteredGames = () => {
    const now = new Date();
    return games.filter(g => {
      if (g.status === 'active') return false; // History only
      const endTime = g.endTime ? new Date(g.endTime) : null;
      if (!endTime) return false;

      const diffDays = Math.ceil(Math.abs(now.getTime() - endTime.getTime()) / (1000 * 60 * 60 * 24));

      if (gameReportFilter === 'daily') return endTime.toDateString() === todayStr;
      if (gameReportFilter === 'weekly') return diffDays <= 7;
      if (gameReportFilter === 'monthly') return endTime.getMonth() === now.getMonth() && endTime.getFullYear() === now.getFullYear();
      if (gameReportFilter === 'yearly') return endTime.getFullYear() === now.getFullYear();

      return true;
    });
  };

  const filteredGamesList = getFilteredGames();

  // Excel exporter
  const handleExportGames = () => {
    const formatted = filteredGamesList.map((g, idx) => ({
      'ተ.ቁ': idx + 1,
      'ካራንቡላ ቦታ': `ቦታ ${g.location}`,
      'የደንበኛ ስም': g.customerName,
      'የተጀመረበት': g.startTime ? new Date(g.startTime).toLocaleTimeString() : '-',
      'የተጠናቀቀበት': g.endTime ? new Date(g.endTime).toLocaleTimeString() : '-',
      'የፈጀው ደቂቃ': g.minutes,
      'ሂሳብ / ክፍያ (ብር)': g.cost
    }));
    downloadExcel(formatted, `ካራንቡላ_ጨዋታዎች_ሪፖርት_${gameReportFilter}`);
  };

  return (
    <div className="space-y-6">
      {/* HEADER CARD */}
      <div className="bg-white p-5 md:p-6 rounded-3xl shadow-md border-t-4 border-purple-600">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-xl md:text-2xl font-black text-slate-800 tracking-tight font-display flex items-center gap-2">
              <Dices className="text-purple-600 animate-spin" /> 🎮 የካራንቡላ አጫዋች ፓነል
            </h2>
            <p className="text-xs text-slate-500 font-medium mt-1">የካራንቡላ (ቢሊያርድ) ቦታዎችን መቆጣጠሪያ፣ ጊዜ መመዝገቢያና የክፍያ ማስያዣ</p>
          </div>
          <span className="text-xs font-bold bg-purple-50 text-purple-700 border border-purple-100 px-3 py-1.5 rounded-full self-start md:self-center">
            ካራንቡላ (Game Player)
          </span>
        </div>
      </div>

      {/* GAME STATUS METRICS */}
      <div className="bg-white p-5 rounded-3xl border border-slate-100 shadow-sm space-y-4">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 text-center">
          <div className="bg-purple-50/50 p-4 border border-purple-100 rounded-2xl">
            <span className="block text-[10px] text-slate-400 font-bold uppercase">በአሁኑ ሰዓት</span>
            <span className="text-base font-black text-purple-700 mt-1 block">
              {openSpots > 0 ? 'ክፍት ነው' : 'ሙሉ በሙሉ ተይዟል'}
            </span>
          </div>
          <div className="bg-slate-50 p-4 border rounded-2xl">
            <span className="block text-[10px] text-slate-400 font-bold uppercase">ክፍት ቦታ</span>
            <span className="text-base font-black text-emerald-600 mt-1 block">{openSpots}</span>
          </div>
          <div className="bg-slate-50 p-4 border rounded-2xl">
            <span className="block text-[10px] text-slate-400 font-bold uppercase">የተያዘ ቦታ</span>
            <span className="text-base font-black text-red-500 mt-1 block">{occupiedSpots}</span>
          </div>
          <div className="bg-emerald-50 border border-emerald-100 p-4 rounded-2xl">
            <span className="block text-[10px] text-emerald-800 font-bold uppercase">የዛሬ ጠቅላላ ገቢ</span>
            <span className="text-base font-black text-emerald-700 mt-1 block">{formatCurrency(dailyGameRevenue)}</span>
          </div>
        </div>

        {/* Location badges list */}
        <div className="flex flex-wrap gap-2 pt-2 justify-center">
          {LOCATIONS.map(loc => {
            const act = activeGames.find(g => g.location === loc);
            return (
              <span
                key={loc}
                className={`text-[10px] font-extrabold px-3 py-1.5 rounded-full border ${
                  act
                    ? 'bg-red-50 border-red-100 text-red-700'
                    : 'bg-emerald-50 border-emerald-100 text-emerald-700'
                }`}
              >
                {act ? `🔴 ቦታ ${loc} (${act.customerName})` : `🟢 ቦታ ${loc} ክፍት`}
              </span>
            );
          })}
        </div>
      </div>

      {/* GAME MANAGEMENT ACTIONS */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Start Game Form */}
        <div className="bg-white p-5 rounded-3xl border border-slate-100 shadow-sm space-y-3 flex flex-col justify-between">
          <h3 className="font-extrabold text-purple-800 text-sm flex items-center gap-1.5">
            <Play size={16} /> 🆕 አዲስ ጨዋታ መጀመር
          </h3>
          <div className="space-y-2 bg-slate-50 p-3 rounded-2xl border">
            <input
              type="text"
              placeholder="የደንበኛ ስም ያስገቡ"
              value={customerNameInput}
              onChange={(e) => setCustomerNameInput(e.target.value)}
              className="w-full border p-2.5 rounded-xl text-xs font-semibold bg-white focus:outline-none"
            />
            <select
              value={selectedLocation}
              onChange={(e) => setSelectedLocation(e.target.value)}
              className="w-full border p-2.5 rounded-xl text-xs font-bold bg-white focus:outline-none"
            >
              {LOCATIONS.map(loc => (
                <option key={loc} value={loc}>ካራንቡላ ቦታ {loc}</option>
              ))}
            </select>
          </div>
          <button
            onClick={handleStartGame}
            className="w-full bg-purple-600 hover:bg-purple-700 text-white font-bold py-2.5 rounded-2xl text-xs shadow-md shadow-purple-500/10 cursor-pointer"
          >
            ጨዋታ ጀምር (ደቂቃ በ 1.70 ብር)
          </button>
        </div>

        {/* End Game Form */}
        <div className="bg-white p-5 rounded-3xl border border-slate-100 shadow-sm space-y-3 flex flex-col justify-between">
          <h3 className="font-extrabold text-red-700 text-sm flex items-center gap-1.5">
            <CheckCircle size={16} /> 🔚 ጨዋታ መዝጋት
          </h3>
          <div className="space-y-2 bg-slate-50 p-3 rounded-2xl border">
            <label className="block text-[10px] font-bold text-slate-500 uppercase">የሚዘጋውን ቦታ ይምረጡ</label>
            <select
              value={selectedEndId}
              onChange={(e) => setSelectedEndId(e.target.value)}
              className="w-full border p-2.5 rounded-xl text-xs font-bold bg-white focus:outline-none mt-1"
            >
              <option value="">-- የሚዘጋ ጨዋታ ይምረጡ --</option>
              {activeGames.map(g => (
                <option key={g.id} value={g.id}>ቦታ {g.location} - {g.customerName}</option>
              ))}
            </select>
          </div>
          <button
            onClick={handleEndGame}
            className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-2.5 rounded-2xl text-xs shadow-md shadow-red-500/10 cursor-pointer"
          >
            ጨዋታ ዝጋ (ደቂቃ አስላ)
          </button>
        </div>
      </div>

      {/* GAME HISTORY & REPORTING */}
      <div className="bg-white p-5 rounded-3xl border border-slate-100 shadow-sm space-y-4">
        <h3 className="font-extrabold text-slate-800 text-sm">📊 የጨዋታ ታሪክና ገቢ ሪፖርት ማውጫ</h3>

        {/* Filters */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-50 p-3 rounded-2xl border">
          <div className="flex items-center gap-2">
            <label className="text-xs font-bold text-slate-500">ማጣሪያ፦</label>
            <select
              value={gameReportFilter}
              onChange={(e: any) => setGameReportFilter(e.target.value)}
              className="p-2 border border-slate-200 rounded-xl text-xs font-bold bg-white"
            >
              <option value="all">ሁሉንም ሪፖርት አሳይ</option>
              <option value="daily">የዛሬ ብቻ</option>
              <option value="weekly">የሳምንት ብቻ</option>
              <option value="monthly">የወር ብቻ</option>
              <option value="yearly">የአመት ብቻ</option>
            </select>
          </div>
          <button
            onClick={handleExportGames}
            className="bg-slate-800 hover:bg-slate-900 text-white px-4 py-2.5 rounded-xl text-xs font-bold shadow flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <Download size={14} /> የጨዋታ ፋይል አውርድ (.xlsx)
          </button>
        </div>

        {/* History table */}
        <div className="overflow-x-auto rounded-2xl border border-slate-100">
          <table className="min-w-full bg-white text-xs text-left">
            <thead className="bg-slate-50 border-b border-slate-100 font-extrabold text-slate-700">
              <tr>
                <th className="p-3 text-center">ቦታ</th>
                <th className="p-3">ደንበኛ ስም</th>
                <th className="p-3">የተጀመረበት ሰዓት</th>
                <th className="p-3">የተዘጋበት ሰዓት</th>
                <th className="p-3 text-center">የፈጀው ደቂቃ</th>
                <th className="p-3 text-right">ጠቅላላ ክፍያ</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium">
              {filteredGamesList.map((g, idx) => (
                <tr key={idx} className="hover:bg-slate-50/50">
                  <td className="p-3 text-center font-bold text-purple-700">ቦታ {g.location}</td>
                  <td className="p-3 font-bold text-slate-800">{g.customerName}</td>
                  <td className="p-3 font-semibold text-slate-600">
                    {g.startTime ? new Date(g.startTime).toLocaleTimeString() : '-'}
                  </td>
                  <td className="p-3 font-semibold text-slate-600">
                    {g.endTime ? new Date(g.endTime).toLocaleTimeString() : '-'}
                  </td>
                  <td className="p-3 text-center font-extrabold text-slate-800">{g.minutes} ደቂቃ</td>
                  <td className="p-3 font-black text-emerald-600 text-right">{formatCurrency(g.cost)}</td>
                </tr>
              ))}
              {filteredGamesList.length === 0 && (
                <tr>
                  <td colSpan={6} className="p-6 text-center text-slate-400 italic font-bold">
                    በዚህ የጊዜ ማጣሪያ የተጠናቀቁ የጨዋታዎች ታሪክ የለም።
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
